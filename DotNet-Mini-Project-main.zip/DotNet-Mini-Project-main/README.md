# DotNet-Mini-Project
Restaurant Management Software: A Windows Form app with an intuitive interface for table booking and food ordering. Developed using C#, SQL, and .NET Framework. Efficiently manages customer data, reservations, and orders with a relational database.
