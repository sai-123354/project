﻿namespace seproject
{
    partial class bookingform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.enterdetails = new System.Windows.Forms.Label();
            this.bleftpanel = new System.Windows.Forms.Panel();
            this.bbackbtn = new System.Windows.Forms.Button();
            this.newbooking = new System.Windows.Forms.Label();
            this.tablecodebox = new System.Windows.Forms.ComboBox();
            this.prefsbox = new System.Windows.Forms.ComboBox();
            this.tablecode = new System.Windows.Forms.Label();
            this.tableprefs = new System.Windows.Forms.Label();
            this.noofseats = new System.Windows.Forms.Label();
            this.selecttime = new System.Windows.Forms.Label();
            this.selectdate = new System.Windows.Forms.Label();
            this.bnumericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btime = new System.Windows.Forms.DateTimePicker();
            this.bdate = new System.Windows.Forms.DateTimePicker();
            this.brightpanel = new System.Windows.Forms.Panel();
            this.tables = new System.Windows.Forms.Panel();
            this.R1tablebtn = new System.Windows.Forms.Button();
            this.R2tablebtn = new System.Windows.Forms.Button();
            this.R3tablebtn = new System.Windows.Forms.Button();
            this.R4tablebtn = new System.Windows.Forms.Button();
            this.R5tablebtn = new System.Windows.Forms.Button();
            this.R6tablebtn = new System.Windows.Forms.Button();
            this.R7tablebtn = new System.Windows.Forms.Button();
            this.R8tablebtn = new System.Windows.Forms.Button();
            this.R9tablebtn = new System.Windows.Forms.Button();
            this.R10tablebtn = new System.Windows.Forms.Button();
            this.R11tablebtn = new System.Windows.Forms.Button();
            this.R12tablebtn = new System.Windows.Forms.Button();
            this.F1tablebtn = new System.Windows.Forms.Button();
            this.F2tablebtn = new System.Windows.Forms.Button();
            this.F3tablebtn = new System.Windows.Forms.Button();
            this.F4tablebtn = new System.Windows.Forms.Button();
            this.F5tablebtn = new System.Windows.Forms.Button();
            this.F6tablebtn = new System.Windows.Forms.Button();
            this.F7tablebtn = new System.Windows.Forms.Button();
            this.F8tablebtn = new System.Windows.Forms.Button();
            this.C1tablebtn = new System.Windows.Forms.Button();
            this.C2tablebtn = new System.Windows.Forms.Button();
            this.C3tablebtn = new System.Windows.Forms.Button();
            this.bproceedbtn = new System.Windows.Forms.Button();
            this.tableselection = new System.Windows.Forms.Label();
            this.regu = new System.Windows.Forms.Label();
            this.ct = new System.Windows.Forms.Label();
            this.fam = new System.Windows.Forms.Label();
            this.bleftpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bnumericUpDown1)).BeginInit();
            this.brightpanel.SuspendLayout();
            this.tables.SuspendLayout();
            this.SuspendLayout();
            // 
            // enterdetails
            // 
            this.enterdetails.AutoSize = true;
            this.enterdetails.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.enterdetails.ForeColor = System.Drawing.SystemColors.Control;
            this.enterdetails.Location = new System.Drawing.Point(16, 74);
            this.enterdetails.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.enterdetails.Name = "enterdetails";
            this.enterdetails.Size = new System.Drawing.Size(227, 40);
            this.enterdetails.TabIndex = 1;
            this.enterdetails.Text = "Enter Details:";
            // 
            // bleftpanel
            // 
            this.bleftpanel.BackColor = System.Drawing.Color.SteelBlue;
            this.bleftpanel.Controls.Add(this.bbackbtn);
            this.bleftpanel.Controls.Add(this.newbooking);
            this.bleftpanel.Controls.Add(this.enterdetails);
            this.bleftpanel.Controls.Add(this.tablecodebox);
            this.bleftpanel.Controls.Add(this.prefsbox);
            this.bleftpanel.Controls.Add(this.tablecode);
            this.bleftpanel.Controls.Add(this.tableprefs);
            this.bleftpanel.Controls.Add(this.noofseats);
            this.bleftpanel.Controls.Add(this.selecttime);
            this.bleftpanel.Controls.Add(this.selectdate);
            this.bleftpanel.Controls.Add(this.bnumericUpDown1);
            this.bleftpanel.Controls.Add(this.btime);
            this.bleftpanel.Controls.Add(this.bdate);
            this.bleftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.bleftpanel.Location = new System.Drawing.Point(0, 0);
            this.bleftpanel.Margin = new System.Windows.Forms.Padding(4);
            this.bleftpanel.Name = "bleftpanel";
            this.bleftpanel.Size = new System.Drawing.Size(427, 615);
            this.bleftpanel.TabIndex = 2;
            // 
            // bbackbtn
            // 
            this.bbackbtn.BackColor = System.Drawing.Color.Transparent;
            this.bbackbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bbackbtn.FlatAppearance.BorderSize = 0;
            this.bbackbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bbackbtn.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bbackbtn.ForeColor = System.Drawing.Color.Gainsboro;
            this.bbackbtn.Location = new System.Drawing.Point(0, 566);
            this.bbackbtn.Margin = new System.Windows.Forms.Padding(4);
            this.bbackbtn.Name = "bbackbtn";
            this.bbackbtn.Size = new System.Drawing.Size(44, 50);
            this.bbackbtn.TabIndex = 3;
            this.bbackbtn.Text = "<";
            this.bbackbtn.UseVisualStyleBackColor = false;
            this.bbackbtn.Click += new System.EventHandler(this.bbackbtn_Click);
            this.bbackbtn.MouseEnter += new System.EventHandler(this.bbackbtn_MouseEnter);
            this.bbackbtn.MouseLeave += new System.EventHandler(this.bbackbtn_MouseLeave);
            // 
            // newbooking
            // 
            this.newbooking.AutoSize = true;
            this.newbooking.Font = new System.Drawing.Font("Century Gothic", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newbooking.ForeColor = System.Drawing.Color.White;
            this.newbooking.Location = new System.Drawing.Point(49, 11);
            this.newbooking.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.newbooking.Name = "newbooking";
            this.newbooking.Size = new System.Drawing.Size(307, 55);
            this.newbooking.TabIndex = 1;
            this.newbooking.Text = "New Booking";
            this.newbooking.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tablecodebox
            // 
            this.tablecodebox.AllowDrop = true;
            this.tablecodebox.BackColor = System.Drawing.Color.White;
            this.tablecodebox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.tablecodebox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.tablecodebox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tablecodebox.ForeColor = System.Drawing.Color.Black;
            this.tablecodebox.FormattingEnabled = true;
            this.tablecodebox.Location = new System.Drawing.Point(27, 492);
            this.tablecodebox.Margin = new System.Windows.Forms.Padding(4);
            this.tablecodebox.MaxDropDownItems = 25;
            this.tablecodebox.Name = "tablecodebox";
            this.tablecodebox.Size = new System.Drawing.Size(265, 31);
            this.tablecodebox.TabIndex = 2;
            this.tablecodebox.Text = " <select>";
            // 
            // prefsbox
            // 
            this.prefsbox.BackColor = System.Drawing.Color.White;
            this.prefsbox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.prefsbox.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.prefsbox.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.prefsbox.ForeColor = System.Drawing.Color.Black;
            this.prefsbox.FormattingEnabled = true;
            this.prefsbox.Items.AddRange(new object[] {
            "Regular Table",
            "Centre Table",
            "Family Table"});
            this.prefsbox.Location = new System.Drawing.Point(24, 407);
            this.prefsbox.Margin = new System.Windows.Forms.Padding(4);
            this.prefsbox.MaxDropDownItems = 4;
            this.prefsbox.Name = "prefsbox";
            this.prefsbox.Size = new System.Drawing.Size(265, 31);
            this.prefsbox.TabIndex = 2;
            this.prefsbox.Text = " <select>";
            this.prefsbox.SelectedIndexChanged += new System.EventHandler(this.prefsbox_SelectedIndexChanged);
            // 
            // tablecode
            // 
            this.tablecode.AutoSize = true;
            this.tablecode.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tablecode.ForeColor = System.Drawing.SystemColors.Control;
            this.tablecode.Location = new System.Drawing.Point(15, 455);
            this.tablecode.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tablecode.Name = "tablecode";
            this.tablecode.Size = new System.Drawing.Size(174, 33);
            this.tablecode.TabIndex = 1;
            this.tablecode.Text = "Table Code:";
            // 
            // tableprefs
            // 
            this.tableprefs.AutoSize = true;
            this.tableprefs.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableprefs.ForeColor = System.Drawing.SystemColors.Control;
            this.tableprefs.Location = new System.Drawing.Point(17, 370);
            this.tableprefs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tableprefs.Name = "tableprefs";
            this.tableprefs.Size = new System.Drawing.Size(255, 33);
            this.tableprefs.TabIndex = 1;
            this.tableprefs.Text = "Table Preferences:";
            // 
            // noofseats
            // 
            this.noofseats.AutoSize = true;
            this.noofseats.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.noofseats.ForeColor = System.Drawing.SystemColors.Control;
            this.noofseats.Location = new System.Drawing.Point(17, 322);
            this.noofseats.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.noofseats.Name = "noofseats";
            this.noofseats.Size = new System.Drawing.Size(178, 33);
            this.noofseats.TabIndex = 1;
            this.noofseats.Text = "No. of Seats:";
            // 
            // selecttime
            // 
            this.selecttime.AutoSize = true;
            this.selecttime.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selecttime.ForeColor = System.Drawing.SystemColors.Control;
            this.selecttime.Location = new System.Drawing.Point(17, 222);
            this.selecttime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selecttime.Name = "selecttime";
            this.selecttime.Size = new System.Drawing.Size(169, 33);
            this.selecttime.TabIndex = 1;
            this.selecttime.Text = "Select Time:";
            // 
            // selectdate
            // 
            this.selectdate.AutoSize = true;
            this.selectdate.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectdate.ForeColor = System.Drawing.SystemColors.Control;
            this.selectdate.Location = new System.Drawing.Point(17, 127);
            this.selectdate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.selectdate.Name = "selectdate";
            this.selectdate.Size = new System.Drawing.Size(172, 33);
            this.selectdate.TabIndex = 1;
            this.selectdate.Text = "Select Date:";
            // 
            // bnumericUpDown1
            // 
            this.bnumericUpDown1.BackColor = System.Drawing.Color.White;
            this.bnumericUpDown1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bnumericUpDown1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.bnumericUpDown1.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnumericUpDown1.ForeColor = System.Drawing.Color.Black;
            this.bnumericUpDown1.Location = new System.Drawing.Point(216, 325);
            this.bnumericUpDown1.Margin = new System.Windows.Forms.Padding(4);
            this.bnumericUpDown1.Maximum = new decimal(new int[] {
            16,
            0,
            0,
            0});
            this.bnumericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.bnumericUpDown1.Name = "bnumericUpDown1";
            this.bnumericUpDown1.Size = new System.Drawing.Size(63, 32);
            this.bnumericUpDown1.TabIndex = 1;
            this.bnumericUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.bnumericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btime
            // 
            this.btime.CalendarForeColor = System.Drawing.Color.SteelBlue;
            this.btime.CalendarMonthBackground = System.Drawing.Color.Gainsboro;
            this.btime.CalendarTitleBackColor = System.Drawing.Color.Gainsboro;
            this.btime.CalendarTitleForeColor = System.Drawing.Color.Gainsboro;
            this.btime.CalendarTrailingForeColor = System.Drawing.Color.DarkRed;
            this.btime.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btime.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btime.Format = System.Windows.Forms.DateTimePickerFormat.Time;
            this.btime.Location = new System.Drawing.Point(24, 258);
            this.btime.Margin = new System.Windows.Forms.Padding(4);
            this.btime.Name = "btime";
            this.btime.ShowUpDown = true;
            this.btime.Size = new System.Drawing.Size(265, 32);
            this.btime.TabIndex = 0;
            this.btime.Value = new System.DateTime(2021, 11, 16, 0, 0, 0, 0);
            // 
            // bdate
            // 
            this.bdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bdate.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bdate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.bdate.Location = new System.Drawing.Point(24, 164);
            this.bdate.Margin = new System.Windows.Forms.Padding(4);
            this.bdate.MinDate = new System.DateTime(2021, 11, 29, 14, 18, 26, 0);
            this.bdate.Name = "bdate";
            this.bdate.Size = new System.Drawing.Size(265, 32);
            this.bdate.TabIndex = 0;
            this.bdate.Value = new System.DateTime(2021, 11, 29, 14, 18, 26, 0);
            // 
            // brightpanel
            // 
            this.brightpanel.BackColor = System.Drawing.Color.Gainsboro;
            this.brightpanel.Controls.Add(this.tables);
            this.brightpanel.Controls.Add(this.bproceedbtn);
            this.brightpanel.Controls.Add(this.tableselection);
            this.brightpanel.Controls.Add(this.regu);
            this.brightpanel.Controls.Add(this.ct);
            this.brightpanel.Controls.Add(this.fam);
            this.brightpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.brightpanel.Location = new System.Drawing.Point(427, 0);
            this.brightpanel.Margin = new System.Windows.Forms.Padding(4);
            this.brightpanel.Name = "brightpanel";
            this.brightpanel.Size = new System.Drawing.Size(746, 615);
            this.brightpanel.TabIndex = 3;
            // 
            // tables
            // 
            this.tables.BackColor = System.Drawing.Color.SteelBlue;
            this.tables.Controls.Add(this.R1tablebtn);
            this.tables.Controls.Add(this.R2tablebtn);
            this.tables.Controls.Add(this.R3tablebtn);
            this.tables.Controls.Add(this.R4tablebtn);
            this.tables.Controls.Add(this.R5tablebtn);
            this.tables.Controls.Add(this.R6tablebtn);
            this.tables.Controls.Add(this.R7tablebtn);
            this.tables.Controls.Add(this.R8tablebtn);
            this.tables.Controls.Add(this.R9tablebtn);
            this.tables.Controls.Add(this.R10tablebtn);
            this.tables.Controls.Add(this.R11tablebtn);
            this.tables.Controls.Add(this.R12tablebtn);
            this.tables.Controls.Add(this.F1tablebtn);
            this.tables.Controls.Add(this.F2tablebtn);
            this.tables.Controls.Add(this.F3tablebtn);
            this.tables.Controls.Add(this.F4tablebtn);
            this.tables.Controls.Add(this.F5tablebtn);
            this.tables.Controls.Add(this.F6tablebtn);
            this.tables.Controls.Add(this.F7tablebtn);
            this.tables.Controls.Add(this.F8tablebtn);
            this.tables.Controls.Add(this.C1tablebtn);
            this.tables.Controls.Add(this.C2tablebtn);
            this.tables.Controls.Add(this.C3tablebtn);
            this.tables.Location = new System.Drawing.Point(77, 66);
            this.tables.Margin = new System.Windows.Forms.Padding(4);
            this.tables.Name = "tables";
            this.tables.Size = new System.Drawing.Size(600, 468);
            this.tables.TabIndex = 4;
            // 
            // R1tablebtn
            // 
            this.R1tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R1tablebtn.Enabled = false;
            this.R1tablebtn.FlatAppearance.BorderSize = 0;
            this.R1tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R1tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R1tablebtn.Location = new System.Drawing.Point(35, 33);
            this.R1tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R1tablebtn.Name = "R1tablebtn";
            this.R1tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R1tablebtn.TabIndex = 0;
            this.R1tablebtn.Text = "RT1";
            this.R1tablebtn.UseVisualStyleBackColor = false;
            // 
            // R2tablebtn
            // 
            this.R2tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R2tablebtn.Enabled = false;
            this.R2tablebtn.FlatAppearance.BorderSize = 0;
            this.R2tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R2tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R2tablebtn.Location = new System.Drawing.Point(125, 33);
            this.R2tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R2tablebtn.Name = "R2tablebtn";
            this.R2tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R2tablebtn.TabIndex = 0;
            this.R2tablebtn.Text = "RT2";
            this.R2tablebtn.UseVisualStyleBackColor = false;
            // 
            // R3tablebtn
            // 
            this.R3tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R3tablebtn.Enabled = false;
            this.R3tablebtn.FlatAppearance.BorderSize = 0;
            this.R3tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R3tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R3tablebtn.Location = new System.Drawing.Point(216, 33);
            this.R3tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R3tablebtn.Name = "R3tablebtn";
            this.R3tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R3tablebtn.TabIndex = 0;
            this.R3tablebtn.Text = "RT3";
            this.R3tablebtn.UseVisualStyleBackColor = false;
            // 
            // R4tablebtn
            // 
            this.R4tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R4tablebtn.Enabled = false;
            this.R4tablebtn.FlatAppearance.BorderSize = 0;
            this.R4tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R4tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R4tablebtn.Location = new System.Drawing.Point(311, 33);
            this.R4tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R4tablebtn.Name = "R4tablebtn";
            this.R4tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R4tablebtn.TabIndex = 0;
            this.R4tablebtn.Text = "RT4";
            this.R4tablebtn.UseVisualStyleBackColor = false;
            // 
            // R5tablebtn
            // 
            this.R5tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R5tablebtn.Enabled = false;
            this.R5tablebtn.FlatAppearance.BorderSize = 0;
            this.R5tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R5tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R5tablebtn.Location = new System.Drawing.Point(403, 33);
            this.R5tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R5tablebtn.Name = "R5tablebtn";
            this.R5tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R5tablebtn.TabIndex = 0;
            this.R5tablebtn.Text = "RT5";
            this.R5tablebtn.UseVisualStyleBackColor = false;
            // 
            // R6tablebtn
            // 
            this.R6tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R6tablebtn.Enabled = false;
            this.R6tablebtn.FlatAppearance.BorderSize = 0;
            this.R6tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R6tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R6tablebtn.Location = new System.Drawing.Point(495, 33);
            this.R6tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R6tablebtn.Name = "R6tablebtn";
            this.R6tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R6tablebtn.TabIndex = 0;
            this.R6tablebtn.Text = "RT6";
            this.R6tablebtn.UseVisualStyleBackColor = false;
            // 
            // R7tablebtn
            // 
            this.R7tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R7tablebtn.Enabled = false;
            this.R7tablebtn.FlatAppearance.BorderSize = 0;
            this.R7tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R7tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R7tablebtn.Location = new System.Drawing.Point(35, 401);
            this.R7tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R7tablebtn.Name = "R7tablebtn";
            this.R7tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R7tablebtn.TabIndex = 0;
            this.R7tablebtn.Text = "RT7";
            this.R7tablebtn.UseVisualStyleBackColor = false;
            // 
            // R8tablebtn
            // 
            this.R8tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R8tablebtn.Enabled = false;
            this.R8tablebtn.FlatAppearance.BorderSize = 0;
            this.R8tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R8tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R8tablebtn.Location = new System.Drawing.Point(125, 401);
            this.R8tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R8tablebtn.Name = "R8tablebtn";
            this.R8tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R8tablebtn.TabIndex = 0;
            this.R8tablebtn.Text = "RT8";
            this.R8tablebtn.UseVisualStyleBackColor = false;
            // 
            // R9tablebtn
            // 
            this.R9tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R9tablebtn.Enabled = false;
            this.R9tablebtn.FlatAppearance.BorderSize = 0;
            this.R9tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R9tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R9tablebtn.Location = new System.Drawing.Point(216, 401);
            this.R9tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R9tablebtn.Name = "R9tablebtn";
            this.R9tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R9tablebtn.TabIndex = 0;
            this.R9tablebtn.Text = "RT9";
            this.R9tablebtn.UseVisualStyleBackColor = false;
            // 
            // R10tablebtn
            // 
            this.R10tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R10tablebtn.Enabled = false;
            this.R10tablebtn.FlatAppearance.BorderSize = 0;
            this.R10tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R10tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R10tablebtn.Location = new System.Drawing.Point(311, 401);
            this.R10tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R10tablebtn.Name = "R10tablebtn";
            this.R10tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R10tablebtn.TabIndex = 0;
            this.R10tablebtn.Text = "RT10";
            this.R10tablebtn.UseVisualStyleBackColor = false;
            // 
            // R11tablebtn
            // 
            this.R11tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R11tablebtn.Enabled = false;
            this.R11tablebtn.FlatAppearance.BorderSize = 0;
            this.R11tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R11tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R11tablebtn.Location = new System.Drawing.Point(403, 401);
            this.R11tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R11tablebtn.Name = "R11tablebtn";
            this.R11tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R11tablebtn.TabIndex = 0;
            this.R11tablebtn.Text = "RT11";
            this.R11tablebtn.UseVisualStyleBackColor = false;
            // 
            // R12tablebtn
            // 
            this.R12tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.R12tablebtn.Enabled = false;
            this.R12tablebtn.FlatAppearance.BorderSize = 0;
            this.R12tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.R12tablebtn.ForeColor = System.Drawing.Color.Black;
            this.R12tablebtn.Location = new System.Drawing.Point(495, 401);
            this.R12tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.R12tablebtn.Name = "R12tablebtn";
            this.R12tablebtn.Size = new System.Drawing.Size(67, 37);
            this.R12tablebtn.TabIndex = 0;
            this.R12tablebtn.Text = "RT12";
            this.R12tablebtn.UseVisualStyleBackColor = false;
            // 
            // F1tablebtn
            // 
            this.F1tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.F1tablebtn.Enabled = false;
            this.F1tablebtn.FlatAppearance.BorderSize = 0;
            this.F1tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F1tablebtn.ForeColor = System.Drawing.Color.Black;
            this.F1tablebtn.Location = new System.Drawing.Point(44, 87);
            this.F1tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.F1tablebtn.Name = "F1tablebtn";
            this.F1tablebtn.Size = new System.Drawing.Size(107, 62);
            this.F1tablebtn.TabIndex = 0;
            this.F1tablebtn.Text = "FT1";
            this.F1tablebtn.UseVisualStyleBackColor = false;
            // 
            // F2tablebtn
            // 
            this.F2tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.F2tablebtn.Enabled = false;
            this.F2tablebtn.FlatAppearance.BorderSize = 0;
            this.F2tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F2tablebtn.ForeColor = System.Drawing.Color.Black;
            this.F2tablebtn.Location = new System.Drawing.Point(177, 87);
            this.F2tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.F2tablebtn.Name = "F2tablebtn";
            this.F2tablebtn.Size = new System.Drawing.Size(107, 62);
            this.F2tablebtn.TabIndex = 0;
            this.F2tablebtn.Text = "FT2";
            this.F2tablebtn.UseVisualStyleBackColor = false;
            // 
            // F3tablebtn
            // 
            this.F3tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.F3tablebtn.Enabled = false;
            this.F3tablebtn.FlatAppearance.BorderSize = 0;
            this.F3tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F3tablebtn.ForeColor = System.Drawing.Color.Black;
            this.F3tablebtn.Location = new System.Drawing.Point(311, 87);
            this.F3tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.F3tablebtn.Name = "F3tablebtn";
            this.F3tablebtn.Size = new System.Drawing.Size(107, 62);
            this.F3tablebtn.TabIndex = 0;
            this.F3tablebtn.Text = "FT3";
            this.F3tablebtn.UseVisualStyleBackColor = false;
            // 
            // F4tablebtn
            // 
            this.F4tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.F4tablebtn.Enabled = false;
            this.F4tablebtn.FlatAppearance.BorderSize = 0;
            this.F4tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F4tablebtn.ForeColor = System.Drawing.Color.Black;
            this.F4tablebtn.Location = new System.Drawing.Point(444, 87);
            this.F4tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.F4tablebtn.Name = "F4tablebtn";
            this.F4tablebtn.Size = new System.Drawing.Size(107, 62);
            this.F4tablebtn.TabIndex = 0;
            this.F4tablebtn.Text = "FT4";
            this.F4tablebtn.UseVisualStyleBackColor = false;
            // 
            // F5tablebtn
            // 
            this.F5tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.F5tablebtn.Enabled = false;
            this.F5tablebtn.FlatAppearance.BorderSize = 0;
            this.F5tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F5tablebtn.ForeColor = System.Drawing.Color.Black;
            this.F5tablebtn.Location = new System.Drawing.Point(44, 313);
            this.F5tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.F5tablebtn.Name = "F5tablebtn";
            this.F5tablebtn.Size = new System.Drawing.Size(107, 62);
            this.F5tablebtn.TabIndex = 0;
            this.F5tablebtn.Text = "FT5";
            this.F5tablebtn.UseVisualStyleBackColor = false;
            // 
            // F6tablebtn
            // 
            this.F6tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.F6tablebtn.Enabled = false;
            this.F6tablebtn.FlatAppearance.BorderSize = 0;
            this.F6tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F6tablebtn.ForeColor = System.Drawing.Color.Black;
            this.F6tablebtn.Location = new System.Drawing.Point(177, 313);
            this.F6tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.F6tablebtn.Name = "F6tablebtn";
            this.F6tablebtn.Size = new System.Drawing.Size(107, 62);
            this.F6tablebtn.TabIndex = 0;
            this.F6tablebtn.Text = "FT6";
            this.F6tablebtn.UseVisualStyleBackColor = false;
            // 
            // F7tablebtn
            // 
            this.F7tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.F7tablebtn.Enabled = false;
            this.F7tablebtn.FlatAppearance.BorderSize = 0;
            this.F7tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F7tablebtn.ForeColor = System.Drawing.Color.Black;
            this.F7tablebtn.Location = new System.Drawing.Point(311, 313);
            this.F7tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.F7tablebtn.Name = "F7tablebtn";
            this.F7tablebtn.Size = new System.Drawing.Size(107, 62);
            this.F7tablebtn.TabIndex = 0;
            this.F7tablebtn.Text = "FT7";
            this.F7tablebtn.UseVisualStyleBackColor = false;
            // 
            // F8tablebtn
            // 
            this.F8tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.F8tablebtn.Enabled = false;
            this.F8tablebtn.FlatAppearance.BorderSize = 0;
            this.F8tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.F8tablebtn.ForeColor = System.Drawing.Color.Black;
            this.F8tablebtn.Location = new System.Drawing.Point(444, 313);
            this.F8tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.F8tablebtn.Name = "F8tablebtn";
            this.F8tablebtn.Size = new System.Drawing.Size(107, 62);
            this.F8tablebtn.TabIndex = 0;
            this.F8tablebtn.Text = "FT8";
            this.F8tablebtn.UseVisualStyleBackColor = false;
            // 
            // C1tablebtn
            // 
            this.C1tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.C1tablebtn.Enabled = false;
            this.C1tablebtn.FlatAppearance.BorderSize = 0;
            this.C1tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C1tablebtn.ForeColor = System.Drawing.Color.Black;
            this.C1tablebtn.Location = new System.Drawing.Point(64, 182);
            this.C1tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.C1tablebtn.Name = "C1tablebtn";
            this.C1tablebtn.Size = new System.Drawing.Size(133, 98);
            this.C1tablebtn.TabIndex = 0;
            this.C1tablebtn.Text = "CT1";
            this.C1tablebtn.UseVisualStyleBackColor = false;
            // 
            // C2tablebtn
            // 
            this.C2tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.C2tablebtn.Enabled = false;
            this.C2tablebtn.FlatAppearance.BorderSize = 0;
            this.C2tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C2tablebtn.ForeColor = System.Drawing.Color.Black;
            this.C2tablebtn.Location = new System.Drawing.Point(232, 182);
            this.C2tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.C2tablebtn.Name = "C2tablebtn";
            this.C2tablebtn.Size = new System.Drawing.Size(133, 98);
            this.C2tablebtn.TabIndex = 0;
            this.C2tablebtn.Text = "CT2";
            this.C2tablebtn.UseVisualStyleBackColor = false;
            // 
            // C3tablebtn
            // 
            this.C3tablebtn.BackColor = System.Drawing.Color.Gainsboro;
            this.C3tablebtn.Enabled = false;
            this.C3tablebtn.FlatAppearance.BorderSize = 0;
            this.C3tablebtn.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.C3tablebtn.ForeColor = System.Drawing.Color.Black;
            this.C3tablebtn.Location = new System.Drawing.Point(400, 182);
            this.C3tablebtn.Margin = new System.Windows.Forms.Padding(4);
            this.C3tablebtn.Name = "C3tablebtn";
            this.C3tablebtn.Size = new System.Drawing.Size(133, 98);
            this.C3tablebtn.TabIndex = 0;
            this.C3tablebtn.Text = "CT3";
            this.C3tablebtn.UseVisualStyleBackColor = false;
            // 
            // bproceedbtn
            // 
            this.bproceedbtn.BackColor = System.Drawing.Color.Transparent;
            this.bproceedbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bproceedbtn.FlatAppearance.BorderSize = 0;
            this.bproceedbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bproceedbtn.Font = new System.Drawing.Font("Verdana", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bproceedbtn.ForeColor = System.Drawing.Color.SteelBlue;
            this.bproceedbtn.Location = new System.Drawing.Point(600, 567);
            this.bproceedbtn.Margin = new System.Windows.Forms.Padding(4);
            this.bproceedbtn.Name = "bproceedbtn";
            this.bproceedbtn.Size = new System.Drawing.Size(160, 50);
            this.bproceedbtn.TabIndex = 3;
            this.bproceedbtn.Text = "Proceed>";
            this.bproceedbtn.UseVisualStyleBackColor = false;
            this.bproceedbtn.Click += new System.EventHandler(this.bproceedbtn_Click);
            this.bproceedbtn.MouseEnter += new System.EventHandler(this.bproceedbtn_MouseEnter);
            this.bproceedbtn.MouseLeave += new System.EventHandler(this.bproceedbtn_MouseLeave);
            // 
            // tableselection
            // 
            this.tableselection.AutoSize = true;
            this.tableselection.Font = new System.Drawing.Font("Century Gothic", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableselection.ForeColor = System.Drawing.Color.SteelBlue;
            this.tableselection.Location = new System.Drawing.Point(188, 11);
            this.tableselection.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tableselection.Name = "tableselection";
            this.tableselection.Size = new System.Drawing.Size(352, 55);
            this.tableselection.TabIndex = 1;
            this.tableselection.Text = "Table Selection";
            this.tableselection.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // regu
            // 
            this.regu.AutoSize = true;
            this.regu.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.regu.ForeColor = System.Drawing.Color.SteelBlue;
            this.regu.Location = new System.Drawing.Point(72, 538);
            this.regu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.regu.Name = "regu";
            this.regu.Size = new System.Drawing.Size(173, 23);
            this.regu.TabIndex = 1;
            this.regu.Text = "R1-Regular Table";
            // 
            // ct
            // 
            this.ct.AutoSize = true;
            this.ct.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ct.ForeColor = System.Drawing.Color.SteelBlue;
            this.ct.Location = new System.Drawing.Point(499, 538);
            this.ct.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ct.Name = "ct";
            this.ct.Size = new System.Drawing.Size(166, 23);
            this.ct.TabIndex = 1;
            this.ct.Text = "CT-Centre Table";
            // 
            // fam
            // 
            this.fam.AutoSize = true;
            this.fam.Font = new System.Drawing.Font("Century Gothic", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fam.ForeColor = System.Drawing.Color.SteelBlue;
            this.fam.Location = new System.Drawing.Point(293, 538);
            this.fam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.fam.Name = "fam";
            this.fam.Size = new System.Drawing.Size(158, 23);
            this.fam.TabIndex = 1;
            this.fam.Text = "FT-Family Table";
            // 
            // bookingform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(1173, 615);
            this.Controls.Add(this.brightpanel);
            this.Controls.Add(this.bleftpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "bookingform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "bookingform";
            this.bleftpanel.ResumeLayout(false);
            this.bleftpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bnumericUpDown1)).EndInit();
            this.brightpanel.ResumeLayout(false);
            this.brightpanel.PerformLayout();
            this.tables.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel bleftpanel;
        private System.Windows.Forms.Panel brightpanel;
        private System.Windows.Forms.Label enterdetails;
        private System.Windows.Forms.DateTimePicker bdate;
        private System.Windows.Forms.ComboBox prefsbox;
        private System.Windows.Forms.NumericUpDown bnumericUpDown1;
        private System.Windows.Forms.DateTimePicker btime;
        private System.Windows.Forms.Label selecttime;
        private System.Windows.Forms.Label selectdate;
        private System.Windows.Forms.Label tableprefs;
        private System.Windows.Forms.Label noofseats;
        private System.Windows.Forms.Button bbackbtn;
        private System.Windows.Forms.Button bproceedbtn;
        private System.Windows.Forms.Label newbooking;
        private System.Windows.Forms.Label tableselection;
        private System.Windows.Forms.Panel tables;
        private System.Windows.Forms.Button R12tablebtn;
        private System.Windows.Forms.Button R11tablebtn;
        private System.Windows.Forms.Button R5tablebtn;
        private System.Windows.Forms.Button R7tablebtn;
        private System.Windows.Forms.Button R6tablebtn;
        private System.Windows.Forms.Button R10tablebtn;
        private System.Windows.Forms.Button R4tablebtn;
        private System.Windows.Forms.Button R9tablebtn;
        private System.Windows.Forms.Button R3tablebtn;
        private System.Windows.Forms.Button R2tablebtn;
        private System.Windows.Forms.Button F5tablebtn;
        private System.Windows.Forms.Button F4tablebtn;
        private System.Windows.Forms.Button F3tablebtn;
        private System.Windows.Forms.Button C2tablebtn;
        private System.Windows.Forms.Button C1tablebtn;
        private System.Windows.Forms.Button R8tablebtn;
        private System.Windows.Forms.Button C3tablebtn;
        private System.Windows.Forms.Button R1tablebtn;
        private System.Windows.Forms.Button F6tablebtn;
        private System.Windows.Forms.Button F7tablebtn;
        private System.Windows.Forms.Button F1tablebtn;
        private System.Windows.Forms.Button F8tablebtn;
        private System.Windows.Forms.Button F2tablebtn;
        private System.Windows.Forms.Label ct;
        private System.Windows.Forms.Label fam;
        private System.Windows.Forms.Label regu;
        private System.Windows.Forms.Label tablecode;
        private System.Windows.Forms.ComboBox tablecodebox;
    }
}