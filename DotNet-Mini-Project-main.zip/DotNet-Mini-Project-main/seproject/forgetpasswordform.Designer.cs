﻿namespace seproject
{
    partial class forgetpasswordform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sleftpanel = new System.Windows.Forms.Panel();
            this.sdevelopername = new System.Windows.Forms.Label();
            this.sdevelopedby = new System.Windows.Forms.Label();
            this.screatenewacc1 = new System.Windows.Forms.Label();
            this.slogintoyouraccount1 = new System.Windows.Forms.Label();
            this.sEasyDine = new System.Windows.Forms.Label();
            this.lrightpanel = new System.Windows.Forms.Panel();
            this.confirmpasswordarea = new System.Windows.Forms.Panel();
            this.passwordshowbtn2 = new System.Windows.Forms.Button();
            this.confirmpasswordbox = new System.Windows.Forms.TextBox();
            this.confirmpassword = new System.Windows.Forms.Label();
            this.createpasswordarea = new System.Windows.Forms.Panel();
            this.passwordshowbtn1 = new System.Windows.Forms.Button();
            this.createpasswordbox = new System.Windows.Forms.TextBox();
            this.createpassword = new System.Windows.Forms.Label();
            this.forgetpasswordbtn = new System.Windows.Forms.Button();
            this.resetbtn = new System.Windows.Forms.Button();
            this.clydenmail = new System.Windows.Forms.LinkLabel();
            this.logintoyouraccount2 = new System.Windows.Forms.Label();
            this.aafilmail = new System.Windows.Forms.LinkLabel();
            this.sclosebtn = new System.Windows.Forms.Button();
            this.support3 = new System.Windows.Forms.Label();
            this.support2 = new System.Windows.Forms.Label();
            this.support1 = new System.Windows.Forms.Label();
            this.passwordarea = new System.Windows.Forms.Panel();
            this.emailbox = new System.Windows.Forms.TextBox();
            this.emailtv = new System.Windows.Forms.Label();
            this.usernamearea = new System.Windows.Forms.Panel();
            this.usernamebox = new System.Windows.Forms.TextBox();
            this.username = new System.Windows.Forms.Label();
            this.sleftpanel.SuspendLayout();
            this.lrightpanel.SuspendLayout();
            this.confirmpasswordarea.SuspendLayout();
            this.createpasswordarea.SuspendLayout();
            this.passwordarea.SuspendLayout();
            this.usernamearea.SuspendLayout();
            this.SuspendLayout();
            // 
            // sleftpanel
            // 
            this.sleftpanel.BackColor = System.Drawing.Color.Teal;
            this.sleftpanel.Controls.Add(this.sdevelopername);
            this.sleftpanel.Controls.Add(this.sdevelopedby);
            this.sleftpanel.Controls.Add(this.screatenewacc1);
            this.sleftpanel.Controls.Add(this.slogintoyouraccount1);
            this.sleftpanel.Controls.Add(this.sEasyDine);
            this.sleftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sleftpanel.Location = new System.Drawing.Point(0, 0);
            this.sleftpanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sleftpanel.Name = "sleftpanel";
            this.sleftpanel.Size = new System.Drawing.Size(507, 615);
            this.sleftpanel.TabIndex = 4;
            // 
            // sdevelopername
            // 
            this.sdevelopername.AutoSize = true;
            this.sdevelopername.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sdevelopername.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sdevelopername.ForeColor = System.Drawing.SystemColors.Control;
            this.sdevelopername.Location = new System.Drawing.Point(189, 549);
            this.sdevelopername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sdevelopername.Name = "sdevelopername";
            this.sdevelopername.Size = new System.Drawing.Size(263, 21);
            this.sdevelopername.TabIndex = 0;
            this.sdevelopername.Text = "Aafil Shaikh | Clyden Pacheco";
            // 
            // sdevelopedby
            // 
            this.sdevelopedby.AutoSize = true;
            this.sdevelopedby.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sdevelopedby.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sdevelopedby.ForeColor = System.Drawing.SystemColors.Control;
            this.sdevelopedby.Location = new System.Drawing.Point(343, 526);
            this.sdevelopedby.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sdevelopedby.Name = "sdevelopedby";
            this.sdevelopedby.Size = new System.Drawing.Size(128, 21);
            this.sdevelopedby.TabIndex = 0;
            this.sdevelopedby.Text = "Developed By";
            // 
            // screatenewacc1
            // 
            this.screatenewacc1.AutoSize = true;
            this.screatenewacc1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.screatenewacc1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.screatenewacc1.ForeColor = System.Drawing.SystemColors.Control;
            this.screatenewacc1.Location = new System.Drawing.Point(115, 281);
            this.screatenewacc1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.screatenewacc1.Name = "screatenewacc1";
            this.screatenewacc1.Size = new System.Drawing.Size(340, 37);
            this.screatenewacc1.TabIndex = 0;
            this.screatenewacc1.Text = "Enter valid credentials";
            // 
            // slogintoyouraccount1
            // 
            this.slogintoyouraccount1.AutoSize = true;
            this.slogintoyouraccount1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.slogintoyouraccount1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slogintoyouraccount1.ForeColor = System.Drawing.SystemColors.Control;
            this.slogintoyouraccount1.Location = new System.Drawing.Point(167, 236);
            this.slogintoyouraccount1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.slogintoyouraccount1.Name = "slogintoyouraccount1";
            this.slogintoyouraccount1.Size = new System.Drawing.Size(298, 37);
            this.slogintoyouraccount1.TabIndex = 0;
            this.slogintoyouraccount1.Text = "Password Recovery";
            // 
            // sEasyDine
            // 
            this.sEasyDine.AutoSize = true;
            this.sEasyDine.Font = new System.Drawing.Font("Century Gothic", 30F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sEasyDine.ForeColor = System.Drawing.SystemColors.Control;
            this.sEasyDine.Location = new System.Drawing.Point(224, 143);
            this.sEasyDine.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sEasyDine.Name = "sEasyDine";
            this.sEasyDine.Size = new System.Drawing.Size(244, 60);
            this.sEasyDine.TabIndex = 0;
            this.sEasyDine.Text = "EasyDine";
            // 
            // lrightpanel
            // 
            this.lrightpanel.BackColor = System.Drawing.Color.Gainsboro;
            this.lrightpanel.Controls.Add(this.confirmpasswordarea);
            this.lrightpanel.Controls.Add(this.createpasswordarea);
            this.lrightpanel.Controls.Add(this.forgetpasswordbtn);
            this.lrightpanel.Controls.Add(this.resetbtn);
            this.lrightpanel.Controls.Add(this.clydenmail);
            this.lrightpanel.Controls.Add(this.logintoyouraccount2);
            this.lrightpanel.Controls.Add(this.aafilmail);
            this.lrightpanel.Controls.Add(this.sclosebtn);
            this.lrightpanel.Controls.Add(this.support3);
            this.lrightpanel.Controls.Add(this.support2);
            this.lrightpanel.Controls.Add(this.support1);
            this.lrightpanel.Controls.Add(this.passwordarea);
            this.lrightpanel.Controls.Add(this.usernamearea);
            this.lrightpanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.lrightpanel.Location = new System.Drawing.Point(506, 0);
            this.lrightpanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lrightpanel.Name = "lrightpanel";
            this.lrightpanel.Size = new System.Drawing.Size(667, 615);
            this.lrightpanel.TabIndex = 5;
            // 
            // confirmpasswordarea
            // 
            this.confirmpasswordarea.BackColor = System.Drawing.Color.White;
            this.confirmpasswordarea.Controls.Add(this.passwordshowbtn2);
            this.confirmpasswordarea.Controls.Add(this.confirmpasswordbox);
            this.confirmpasswordarea.Controls.Add(this.confirmpassword);
            this.confirmpasswordarea.Location = new System.Drawing.Point(33, 293);
            this.confirmpasswordarea.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.confirmpasswordarea.Name = "confirmpasswordarea";
            this.confirmpasswordarea.Size = new System.Drawing.Size(607, 37);
            this.confirmpasswordarea.TabIndex = 5;
            // 
            // passwordshowbtn2
            // 
            this.passwordshowbtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.passwordshowbtn2.FlatAppearance.BorderSize = 0;
            this.passwordshowbtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.passwordshowbtn2.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordshowbtn2.ForeColor = System.Drawing.Color.Teal;
            this.passwordshowbtn2.Location = new System.Drawing.Point(573, 1);
            this.passwordshowbtn2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passwordshowbtn2.Name = "passwordshowbtn2";
            this.passwordshowbtn2.Size = new System.Drawing.Size(33, 34);
            this.passwordshowbtn2.TabIndex = 5;
            this.passwordshowbtn2.Text = "*";
            this.passwordshowbtn2.UseVisualStyleBackColor = true;
            this.passwordshowbtn2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.passwordshowbtn2_MouseDown);
            this.passwordshowbtn2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.passwordshowbtn2_MouseUp);
            // 
            // confirmpasswordbox
            // 
            this.confirmpasswordbox.BackColor = System.Drawing.Color.White;
            this.confirmpasswordbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.confirmpasswordbox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmpasswordbox.ForeColor = System.Drawing.Color.Teal;
            this.confirmpasswordbox.Location = new System.Drawing.Point(244, 4);
            this.confirmpasswordbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.confirmpasswordbox.MaxLength = 30;
            this.confirmpasswordbox.Name = "confirmpasswordbox";
            this.confirmpasswordbox.Size = new System.Drawing.Size(332, 29);
            this.confirmpasswordbox.TabIndex = 0;
            this.confirmpasswordbox.UseSystemPasswordChar = true;
            // 
            // confirmpassword
            // 
            this.confirmpassword.AutoSize = true;
            this.confirmpassword.BackColor = System.Drawing.Color.Transparent;
            this.confirmpassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.confirmpassword.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmpassword.ForeColor = System.Drawing.Color.Teal;
            this.confirmpassword.Location = new System.Drawing.Point(4, 5);
            this.confirmpassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.confirmpassword.Name = "confirmpassword";
            this.confirmpassword.Size = new System.Drawing.Size(227, 28);
            this.confirmpassword.TabIndex = 0;
            this.confirmpassword.Text = "confirm password:";
            // 
            // createpasswordarea
            // 
            this.createpasswordarea.BackColor = System.Drawing.Color.White;
            this.createpasswordarea.Controls.Add(this.passwordshowbtn1);
            this.createpasswordarea.Controls.Add(this.createpasswordbox);
            this.createpasswordarea.Controls.Add(this.createpassword);
            this.createpasswordarea.Location = new System.Drawing.Point(33, 236);
            this.createpasswordarea.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.createpasswordarea.Name = "createpasswordarea";
            this.createpasswordarea.Size = new System.Drawing.Size(607, 37);
            this.createpasswordarea.TabIndex = 6;
            // 
            // passwordshowbtn1
            // 
            this.passwordshowbtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.passwordshowbtn1.FlatAppearance.BorderSize = 0;
            this.passwordshowbtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.passwordshowbtn1.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordshowbtn1.ForeColor = System.Drawing.Color.Teal;
            this.passwordshowbtn1.Location = new System.Drawing.Point(573, 1);
            this.passwordshowbtn1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passwordshowbtn1.Name = "passwordshowbtn1";
            this.passwordshowbtn1.Size = new System.Drawing.Size(33, 34);
            this.passwordshowbtn1.TabIndex = 5;
            this.passwordshowbtn1.Text = "*";
            this.passwordshowbtn1.UseVisualStyleBackColor = true;
            this.passwordshowbtn1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.passwordshowbtn1_MouseDown);
            this.passwordshowbtn1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.passwordshowbtn1_MouseUp);
            // 
            // createpasswordbox
            // 
            this.createpasswordbox.BackColor = System.Drawing.Color.White;
            this.createpasswordbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.createpasswordbox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createpasswordbox.ForeColor = System.Drawing.Color.Teal;
            this.createpasswordbox.Location = new System.Drawing.Point(244, 4);
            this.createpasswordbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.createpasswordbox.MaxLength = 30;
            this.createpasswordbox.Name = "createpasswordbox";
            this.createpasswordbox.Size = new System.Drawing.Size(332, 29);
            this.createpasswordbox.TabIndex = 0;
            this.createpasswordbox.UseSystemPasswordChar = true;
            // 
            // createpassword
            // 
            this.createpassword.AutoSize = true;
            this.createpassword.BackColor = System.Drawing.Color.Transparent;
            this.createpassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.createpassword.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createpassword.ForeColor = System.Drawing.Color.Teal;
            this.createpassword.Location = new System.Drawing.Point(4, 5);
            this.createpassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.createpassword.Name = "createpassword";
            this.createpassword.Size = new System.Drawing.Size(214, 28);
            this.createpassword.TabIndex = 0;
            this.createpassword.Text = "create password:";
            // 
            // forgetpasswordbtn
            // 
            this.forgetpasswordbtn.BackColor = System.Drawing.Color.Silver;
            this.forgetpasswordbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.forgetpasswordbtn.FlatAppearance.BorderSize = 0;
            this.forgetpasswordbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.forgetpasswordbtn.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forgetpasswordbtn.ForeColor = System.Drawing.Color.Teal;
            this.forgetpasswordbtn.Location = new System.Drawing.Point(305, 373);
            this.forgetpasswordbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.forgetpasswordbtn.Name = "forgetpasswordbtn";
            this.forgetpasswordbtn.Size = new System.Drawing.Size(281, 49);
            this.forgetpasswordbtn.TabIndex = 4;
            this.forgetpasswordbtn.Text = "Back To Login";
            this.forgetpasswordbtn.UseVisualStyleBackColor = false;
            this.forgetpasswordbtn.Click += new System.EventHandler(this.forgetpasswordbtn_Click);
            // 
            // resetbtn
            // 
            this.resetbtn.BackColor = System.Drawing.Color.Teal;
            this.resetbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.resetbtn.FlatAppearance.BorderSize = 0;
            this.resetbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.resetbtn.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.resetbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.resetbtn.Location = new System.Drawing.Point(67, 373);
            this.resetbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.resetbtn.Name = "resetbtn";
            this.resetbtn.Size = new System.Drawing.Size(227, 49);
            this.resetbtn.TabIndex = 4;
            this.resetbtn.Text = "RESET";
            this.resetbtn.UseVisualStyleBackColor = false;
            this.resetbtn.Click += new System.EventHandler(this.resetbtn_Click);
            // 
            // clydenmail
            // 
            this.clydenmail.AutoSize = true;
            this.clydenmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.clydenmail.LinkColor = System.Drawing.Color.Teal;
            this.clydenmail.Location = new System.Drawing.Point(464, 580);
            this.clydenmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.clydenmail.Name = "clydenmail";
            this.clydenmail.Size = new System.Drawing.Size(176, 16);
            this.clydenmail.TabIndex = 3;
            this.clydenmail.TabStop = true;
            this.clydenmail.Text = "clydenpacheco@gmail.com";
            // 
            // logintoyouraccount2
            // 
            this.logintoyouraccount2.AutoSize = true;
            this.logintoyouraccount2.BackColor = System.Drawing.Color.Transparent;
            this.logintoyouraccount2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logintoyouraccount2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logintoyouraccount2.ForeColor = System.Drawing.Color.Teal;
            this.logintoyouraccount2.Location = new System.Drawing.Point(27, 43);
            this.logintoyouraccount2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.logintoyouraccount2.Name = "logintoyouraccount2";
            this.logintoyouraccount2.Size = new System.Drawing.Size(249, 37);
            this.logintoyouraccount2.TabIndex = 0;
            this.logintoyouraccount2.Text = "Reset Password:\r\n";
            // 
            // aafilmail
            // 
            this.aafilmail.AutoSize = true;
            this.aafilmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.aafilmail.LinkColor = System.Drawing.Color.Teal;
            this.aafilmail.Location = new System.Drawing.Point(271, 580);
            this.aafilmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.aafilmail.Name = "aafilmail";
            this.aafilmail.Size = new System.Drawing.Size(175, 16);
            this.aafilmail.TabIndex = 3;
            this.aafilmail.TabStop = true;
            this.aafilmail.Text = "aafilshaikh1043@gmail.com";
            // 
            // sclosebtn
            // 
            this.sclosebtn.BackColor = System.Drawing.Color.Transparent;
            this.sclosebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sclosebtn.FlatAppearance.BorderSize = 0;
            this.sclosebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sclosebtn.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sclosebtn.ForeColor = System.Drawing.Color.Teal;
            this.sclosebtn.Location = new System.Drawing.Point(616, 0);
            this.sclosebtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sclosebtn.Name = "sclosebtn";
            this.sclosebtn.Size = new System.Drawing.Size(51, 47);
            this.sclosebtn.TabIndex = 2;
            this.sclosebtn.Text = "X";
            this.sclosebtn.UseVisualStyleBackColor = false;
            this.sclosebtn.Click += new System.EventHandler(this.sclosebtn_Click);
            this.sclosebtn.MouseEnter += new System.EventHandler(this.sclosebtn_MouseEnter);
            this.sclosebtn.MouseLeave += new System.EventHandler(this.sclosebtn_MouseLeave);
            // 
            // support3
            // 
            this.support3.AutoSize = true;
            this.support3.BackColor = System.Drawing.Color.Transparent;
            this.support3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.support3.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.support3.ForeColor = System.Drawing.Color.DarkGray;
            this.support3.Location = new System.Drawing.Point(8, 577);
            this.support3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.support3.Name = "support3";
            this.support3.Size = new System.Drawing.Size(231, 21);
            this.support3.TabIndex = 0;
            this.support3.Text = "Mail and Connect with Us:";
            // 
            // support2
            // 
            this.support2.AutoSize = true;
            this.support2.BackColor = System.Drawing.Color.Transparent;
            this.support2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.support2.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.support2.ForeColor = System.Drawing.Color.DarkGray;
            this.support2.Location = new System.Drawing.Point(8, 554);
            this.support2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.support2.Name = "support2";
            this.support2.Size = new System.Drawing.Size(347, 21);
            this.support2.TabIndex = 0;
            this.support2.Text = "Ask a query or access further information";
            // 
            // support1
            // 
            this.support1.AutoSize = true;
            this.support1.BackColor = System.Drawing.Color.Transparent;
            this.support1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.support1.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.support1.ForeColor = System.Drawing.Color.DarkGray;
            this.support1.Location = new System.Drawing.Point(8, 530);
            this.support1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.support1.Name = "support1";
            this.support1.Size = new System.Drawing.Size(80, 21);
            this.support1.TabIndex = 0;
            this.support1.Text = "Support:";
            // 
            // passwordarea
            // 
            this.passwordarea.BackColor = System.Drawing.Color.White;
            this.passwordarea.Controls.Add(this.emailbox);
            this.passwordarea.Controls.Add(this.emailtv);
            this.passwordarea.Location = new System.Drawing.Point(33, 171);
            this.passwordarea.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passwordarea.Name = "passwordarea";
            this.passwordarea.Size = new System.Drawing.Size(587, 37);
            this.passwordarea.TabIndex = 1;
            // 
            // emailbox
            // 
            this.emailbox.BackColor = System.Drawing.Color.White;
            this.emailbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.emailbox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailbox.ForeColor = System.Drawing.Color.Teal;
            this.emailbox.Location = new System.Drawing.Point(112, 5);
            this.emailbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.emailbox.Name = "emailbox";
            this.emailbox.Size = new System.Drawing.Size(419, 29);
            this.emailbox.TabIndex = 0;
            // 
            // emailtv
            // 
            this.emailtv.AutoSize = true;
            this.emailtv.BackColor = System.Drawing.Color.Transparent;
            this.emailtv.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.emailtv.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailtv.ForeColor = System.Drawing.Color.Teal;
            this.emailtv.Location = new System.Drawing.Point(4, 5);
            this.emailtv.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.emailtv.Name = "emailtv";
            this.emailtv.Size = new System.Drawing.Size(83, 28);
            this.emailtv.TabIndex = 0;
            this.emailtv.Text = "Email:";
            // 
            // usernamearea
            // 
            this.usernamearea.BackColor = System.Drawing.Color.White;
            this.usernamearea.Controls.Add(this.usernamebox);
            this.usernamearea.Controls.Add(this.username);
            this.usernamearea.Location = new System.Drawing.Point(33, 106);
            this.usernamearea.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usernamearea.Name = "usernamearea";
            this.usernamearea.Size = new System.Drawing.Size(587, 37);
            this.usernamearea.TabIndex = 1;
            // 
            // usernamebox
            // 
            this.usernamebox.BackColor = System.Drawing.Color.White;
            this.usernamebox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.usernamebox.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.usernamebox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernamebox.ForeColor = System.Drawing.Color.Teal;
            this.usernamebox.Location = new System.Drawing.Point(175, 4);
            this.usernamebox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usernamebox.MaxLength = 30;
            this.usernamebox.Name = "usernamebox";
            this.usernamebox.Size = new System.Drawing.Size(401, 29);
            this.usernamebox.TabIndex = 0;
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.BackColor = System.Drawing.Color.Transparent;
            this.username.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.username.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.ForeColor = System.Drawing.Color.Teal;
            this.username.Location = new System.Drawing.Point(4, 5);
            this.username.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(137, 28);
            this.username.TabIndex = 0;
            this.username.Text = "username:";
            // 
            // forgetpasswordform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1173, 615);
            this.Controls.Add(this.lrightpanel);
            this.Controls.Add(this.sleftpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "forgetpasswordform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "forgetpasswordform";
            this.sleftpanel.ResumeLayout(false);
            this.sleftpanel.PerformLayout();
            this.lrightpanel.ResumeLayout(false);
            this.lrightpanel.PerformLayout();
            this.confirmpasswordarea.ResumeLayout(false);
            this.confirmpasswordarea.PerformLayout();
            this.createpasswordarea.ResumeLayout(false);
            this.createpasswordarea.PerformLayout();
            this.passwordarea.ResumeLayout(false);
            this.passwordarea.PerformLayout();
            this.usernamearea.ResumeLayout(false);
            this.usernamearea.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sleftpanel;
        private System.Windows.Forms.Label sdevelopername;
        private System.Windows.Forms.Label sdevelopedby;
        private System.Windows.Forms.Label screatenewacc1;
        private System.Windows.Forms.Label slogintoyouraccount1;
        private System.Windows.Forms.Label sEasyDine;
        private System.Windows.Forms.Panel lrightpanel;
        private System.Windows.Forms.Button forgetpasswordbtn;
        private System.Windows.Forms.Button resetbtn;
        private System.Windows.Forms.LinkLabel clydenmail;
        private System.Windows.Forms.Label logintoyouraccount2;
        private System.Windows.Forms.LinkLabel aafilmail;
        private System.Windows.Forms.Button sclosebtn;
        private System.Windows.Forms.Label support3;
        private System.Windows.Forms.Label support2;
        private System.Windows.Forms.Label support1;
        private System.Windows.Forms.Panel passwordarea;
        private System.Windows.Forms.TextBox emailbox;
        private System.Windows.Forms.Label emailtv;
        private System.Windows.Forms.Panel usernamearea;
        private System.Windows.Forms.TextBox usernamebox;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Panel confirmpasswordarea;
        private System.Windows.Forms.Button passwordshowbtn2;
        private System.Windows.Forms.TextBox confirmpasswordbox;
        private System.Windows.Forms.Label confirmpassword;
        private System.Windows.Forms.Panel createpasswordarea;
        private System.Windows.Forms.Button passwordshowbtn1;
        private System.Windows.Forms.TextBox createpasswordbox;
        private System.Windows.Forms.Label createpassword;
    }
}