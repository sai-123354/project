﻿namespace seproject
{
    partial class loginform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lleftpanel = new System.Windows.Forms.Panel();
            this.developername = new System.Windows.Forms.Label();
            this.developedby = new System.Windows.Forms.Label();
            this.Createnewacc = new System.Windows.Forms.Label();
            this.logintoyouraccount1 = new System.Windows.Forms.Label();
            this.lEasyDine = new System.Windows.Forms.Label();
            this.lrightpanel = new System.Windows.Forms.Panel();
            this.signupbtn = new System.Windows.Forms.Button();
            this.forgetpasswordbtn = new System.Windows.Forms.Button();
            this.loginbtn = new System.Windows.Forms.Button();
            this.logintoyouraccount2 = new System.Windows.Forms.Label();
            this.sclosebtn = new System.Windows.Forms.Button();
            this.support3 = new System.Windows.Forms.Label();
            this.support2 = new System.Windows.Forms.Label();
            this.support1 = new System.Windows.Forms.Label();
            this.passwordarea = new System.Windows.Forms.Panel();
            this.showpasswordbtn = new System.Windows.Forms.Button();
            this.passwordbox = new System.Windows.Forms.TextBox();
            this.password = new System.Windows.Forms.Label();
            this.usernamearea = new System.Windows.Forms.Panel();
            this.usernamebox = new System.Windows.Forms.TextBox();
            this.username = new System.Windows.Forms.Label();
            this.lleftpanel.SuspendLayout();
            this.lrightpanel.SuspendLayout();
            this.passwordarea.SuspendLayout();
            this.usernamearea.SuspendLayout();
            this.SuspendLayout();
            // 
            // lleftpanel
            // 
            this.lleftpanel.BackColor = System.Drawing.Color.Teal;
            this.lleftpanel.Controls.Add(this.developername);
            this.lleftpanel.Controls.Add(this.developedby);
            this.lleftpanel.Controls.Add(this.Createnewacc);
            this.lleftpanel.Controls.Add(this.logintoyouraccount1);
            this.lleftpanel.Controls.Add(this.lEasyDine);
            this.lleftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.lleftpanel.Location = new System.Drawing.Point(0, 0);
            this.lleftpanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lleftpanel.Name = "lleftpanel";
            this.lleftpanel.Size = new System.Drawing.Size(507, 615);
            this.lleftpanel.TabIndex = 0;
            // 
            // developername
            // 
            this.developername.AutoSize = true;
            this.developername.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.developername.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.developername.ForeColor = System.Drawing.SystemColors.Control;
            this.developername.Location = new System.Drawing.Point(417, 563);
            this.developername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.developername.Name = "developername";
            this.developername.Size = new System.Drawing.Size(47, 21);
            this.developername.TabIndex = 0;
            this.developername.Text = "A2G";
            // 
            // developedby
            // 
            this.developedby.AutoSize = true;
            this.developedby.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.developedby.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.developedby.ForeColor = System.Drawing.SystemColors.Control;
            this.developedby.Location = new System.Drawing.Point(340, 530);
            this.developedby.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.developedby.Name = "developedby";
            this.developedby.Size = new System.Drawing.Size(128, 21);
            this.developedby.TabIndex = 0;
            this.developedby.Text = "Developed By";
            // 
            // Createnewacc
            // 
            this.Createnewacc.AutoSize = true;
            this.Createnewacc.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Createnewacc.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Createnewacc.ForeColor = System.Drawing.SystemColors.Control;
            this.Createnewacc.Location = new System.Drawing.Point(100, 281);
            this.Createnewacc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Createnewacc.Name = "Createnewacc";
            this.Createnewacc.Size = new System.Drawing.Size(349, 37);
            this.Createnewacc.TabIndex = 0;
            this.Createnewacc.Text = "Create a new account";
            // 
            // logintoyouraccount1
            // 
            this.logintoyouraccount1.AutoSize = true;
            this.logintoyouraccount1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logintoyouraccount1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logintoyouraccount1.ForeColor = System.Drawing.SystemColors.Control;
            this.logintoyouraccount1.Location = new System.Drawing.Point(115, 236);
            this.logintoyouraccount1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.logintoyouraccount1.Name = "logintoyouraccount1";
            this.logintoyouraccount1.Size = new System.Drawing.Size(339, 37);
            this.logintoyouraccount1.TabIndex = 0;
            this.logintoyouraccount1.Text = "Login to your account";
            // 
            // lEasyDine
            // 
            this.lEasyDine.AutoSize = true;
            this.lEasyDine.Font = new System.Drawing.Font("Century Gothic", 30F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lEasyDine.ForeColor = System.Drawing.SystemColors.Control;
            this.lEasyDine.Location = new System.Drawing.Point(220, 148);
            this.lEasyDine.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lEasyDine.Name = "lEasyDine";
            this.lEasyDine.Size = new System.Drawing.Size(244, 60);
            this.lEasyDine.TabIndex = 0;
            this.lEasyDine.Text = "EasyDine";
            // 
            // lrightpanel
            // 
            this.lrightpanel.BackColor = System.Drawing.Color.Gainsboro;
            this.lrightpanel.Controls.Add(this.signupbtn);
            this.lrightpanel.Controls.Add(this.forgetpasswordbtn);
            this.lrightpanel.Controls.Add(this.loginbtn);
            this.lrightpanel.Controls.Add(this.logintoyouraccount2);
            this.lrightpanel.Controls.Add(this.sclosebtn);
            this.lrightpanel.Controls.Add(this.support3);
            this.lrightpanel.Controls.Add(this.support2);
            this.lrightpanel.Controls.Add(this.support1);
            this.lrightpanel.Controls.Add(this.passwordarea);
            this.lrightpanel.Controls.Add(this.usernamearea);
            this.lrightpanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.lrightpanel.Location = new System.Drawing.Point(506, 0);
            this.lrightpanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lrightpanel.Name = "lrightpanel";
            this.lrightpanel.Size = new System.Drawing.Size(667, 615);
            this.lrightpanel.TabIndex = 1;
            // 
            // signupbtn
            // 
            this.signupbtn.BackColor = System.Drawing.Color.Silver;
            this.signupbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.signupbtn.FlatAppearance.BorderSize = 0;
            this.signupbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.signupbtn.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.signupbtn.ForeColor = System.Drawing.Color.Teal;
            this.signupbtn.Location = new System.Drawing.Point(213, 446);
            this.signupbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.signupbtn.Name = "signupbtn";
            this.signupbtn.Size = new System.Drawing.Size(227, 49);
            this.signupbtn.TabIndex = 4;
            this.signupbtn.Text = "SIGN UP";
            this.signupbtn.UseVisualStyleBackColor = false;
            this.signupbtn.Click += new System.EventHandler(this.signupbtn_Click);
            // 
            // forgetpasswordbtn
            // 
            this.forgetpasswordbtn.BackColor = System.Drawing.Color.Silver;
            this.forgetpasswordbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.forgetpasswordbtn.FlatAppearance.BorderSize = 0;
            this.forgetpasswordbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.forgetpasswordbtn.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.forgetpasswordbtn.ForeColor = System.Drawing.Color.Teal;
            this.forgetpasswordbtn.Location = new System.Drawing.Point(305, 373);
            this.forgetpasswordbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.forgetpasswordbtn.Name = "forgetpasswordbtn";
            this.forgetpasswordbtn.Size = new System.Drawing.Size(281, 49);
            this.forgetpasswordbtn.TabIndex = 4;
            this.forgetpasswordbtn.Text = "Forget Password?";
            this.forgetpasswordbtn.UseVisualStyleBackColor = false;
            this.forgetpasswordbtn.Click += new System.EventHandler(this.forgetpasswordbtn_Click);
            // 
            // loginbtn
            // 
            this.loginbtn.BackColor = System.Drawing.Color.Teal;
            this.loginbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.loginbtn.FlatAppearance.BorderSize = 0;
            this.loginbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.loginbtn.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.loginbtn.Location = new System.Drawing.Point(67, 373);
            this.loginbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.loginbtn.Name = "loginbtn";
            this.loginbtn.Size = new System.Drawing.Size(227, 49);
            this.loginbtn.TabIndex = 4;
            this.loginbtn.Text = "LOGIN";
            this.loginbtn.UseVisualStyleBackColor = false;
            this.loginbtn.Click += new System.EventHandler(this.loginbtn_Click);
            // 
            // logintoyouraccount2
            // 
            this.logintoyouraccount2.AutoSize = true;
            this.logintoyouraccount2.BackColor = System.Drawing.Color.Transparent;
            this.logintoyouraccount2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.logintoyouraccount2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logintoyouraccount2.ForeColor = System.Drawing.Color.Teal;
            this.logintoyouraccount2.Location = new System.Drawing.Point(32, 167);
            this.logintoyouraccount2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.logintoyouraccount2.Name = "logintoyouraccount2";
            this.logintoyouraccount2.Size = new System.Drawing.Size(348, 37);
            this.logintoyouraccount2.TabIndex = 0;
            this.logintoyouraccount2.Text = "Login to your account:\r\n";
            // 
            // sclosebtn
            // 
            this.sclosebtn.BackColor = System.Drawing.Color.Transparent;
            this.sclosebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sclosebtn.FlatAppearance.BorderSize = 0;
            this.sclosebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sclosebtn.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sclosebtn.ForeColor = System.Drawing.Color.Teal;
            this.sclosebtn.Location = new System.Drawing.Point(616, 0);
            this.sclosebtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.sclosebtn.Name = "sclosebtn";
            this.sclosebtn.Size = new System.Drawing.Size(51, 47);
            this.sclosebtn.TabIndex = 2;
            this.sclosebtn.Text = "X";
            this.sclosebtn.UseVisualStyleBackColor = false;
            this.sclosebtn.Click += new System.EventHandler(this.closebtn_Click);
            this.sclosebtn.MouseEnter += new System.EventHandler(this.sclosebtn_MouseEnter);
            this.sclosebtn.MouseLeave += new System.EventHandler(this.sclosebtn_MouseLeave);
            // 
            // support3
            // 
            this.support3.AutoSize = true;
            this.support3.BackColor = System.Drawing.Color.Transparent;
            this.support3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.support3.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.support3.ForeColor = System.Drawing.Color.DarkGray;
            this.support3.Location = new System.Drawing.Point(8, 577);
            this.support3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.support3.Name = "support3";
            this.support3.Size = new System.Drawing.Size(231, 21);
            this.support3.TabIndex = 0;
            this.support3.Text = "Mail and Connect with Us:";
            // 
            // support2
            // 
            this.support2.AutoSize = true;
            this.support2.BackColor = System.Drawing.Color.Transparent;
            this.support2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.support2.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.support2.ForeColor = System.Drawing.Color.DarkGray;
            this.support2.Location = new System.Drawing.Point(8, 554);
            this.support2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.support2.Name = "support2";
            this.support2.Size = new System.Drawing.Size(347, 21);
            this.support2.TabIndex = 0;
            this.support2.Text = "Ask a query or access further information";
            // 
            // support1
            // 
            this.support1.AutoSize = true;
            this.support1.BackColor = System.Drawing.Color.Transparent;
            this.support1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.support1.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.support1.ForeColor = System.Drawing.Color.DarkGray;
            this.support1.Location = new System.Drawing.Point(8, 530);
            this.support1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.support1.Name = "support1";
            this.support1.Size = new System.Drawing.Size(80, 21);
            this.support1.TabIndex = 0;
            this.support1.Text = "Support:";
            // 
            // passwordarea
            // 
            this.passwordarea.BackColor = System.Drawing.Color.White;
            this.passwordarea.Controls.Add(this.showpasswordbtn);
            this.passwordarea.Controls.Add(this.passwordbox);
            this.passwordarea.Controls.Add(this.password);
            this.passwordarea.Location = new System.Drawing.Point(39, 281);
            this.passwordarea.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passwordarea.Name = "passwordarea";
            this.passwordarea.Size = new System.Drawing.Size(587, 55);
            this.passwordarea.TabIndex = 1;
            // 
            // showpasswordbtn
            // 
            this.showpasswordbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.showpasswordbtn.FlatAppearance.BorderSize = 0;
            this.showpasswordbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.showpasswordbtn.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.showpasswordbtn.ForeColor = System.Drawing.Color.Teal;
            this.showpasswordbtn.Location = new System.Drawing.Point(549, 11);
            this.showpasswordbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.showpasswordbtn.Name = "showpasswordbtn";
            this.showpasswordbtn.Size = new System.Drawing.Size(33, 34);
            this.showpasswordbtn.TabIndex = 5;
            this.showpasswordbtn.Text = "*";
            this.showpasswordbtn.UseVisualStyleBackColor = true;
            this.showpasswordbtn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button3_MouseDown);
            this.showpasswordbtn.MouseUp += new System.Windows.Forms.MouseEventHandler(this.button3_MouseUp);
            // 
            // passwordbox
            // 
            this.passwordbox.BackColor = System.Drawing.Color.White;
            this.passwordbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passwordbox.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordbox.ForeColor = System.Drawing.Color.Teal;
            this.passwordbox.Location = new System.Drawing.Point(171, 10);
            this.passwordbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.passwordbox.Name = "passwordbox";
            this.passwordbox.Size = new System.Drawing.Size(360, 37);
            this.passwordbox.TabIndex = 0;
            this.passwordbox.UseSystemPasswordChar = true;
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.BackColor = System.Drawing.Color.Transparent;
            this.password.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.password.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.Color.Teal;
            this.password.Location = new System.Drawing.Point(4, 12);
            this.password.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(145, 33);
            this.password.TabIndex = 0;
            this.password.Text = "password:";
            // 
            // usernamearea
            // 
            this.usernamearea.BackColor = System.Drawing.Color.White;
            this.usernamearea.Controls.Add(this.usernamebox);
            this.usernamearea.Controls.Add(this.username);
            this.usernamearea.Location = new System.Drawing.Point(39, 215);
            this.usernamearea.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usernamearea.Name = "usernamearea";
            this.usernamearea.Size = new System.Drawing.Size(587, 55);
            this.usernamearea.TabIndex = 1;
            // 
            // usernamebox
            // 
            this.usernamebox.BackColor = System.Drawing.Color.White;
            this.usernamebox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.usernamebox.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.usernamebox.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.usernamebox.ForeColor = System.Drawing.Color.Teal;
            this.usernamebox.Location = new System.Drawing.Point(175, 9);
            this.usernamebox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.usernamebox.MaxLength = 30;
            this.usernamebox.Name = "usernamebox";
            this.usernamebox.Size = new System.Drawing.Size(401, 37);
            this.usernamebox.TabIndex = 0;
            // 
            // username
            // 
            this.username.AutoSize = true;
            this.username.BackColor = System.Drawing.Color.Transparent;
            this.username.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.username.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.username.ForeColor = System.Drawing.Color.Teal;
            this.username.Location = new System.Drawing.Point(4, 12);
            this.username.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.username.Name = "username";
            this.username.Size = new System.Drawing.Size(152, 33);
            this.username.TabIndex = 0;
            this.username.Text = "username:";
            // 
            // loginform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1173, 615);
            this.Controls.Add(this.lrightpanel);
            this.Controls.Add(this.lleftpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "loginform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "loginform";
            this.lleftpanel.ResumeLayout(false);
            this.lleftpanel.PerformLayout();
            this.lrightpanel.ResumeLayout(false);
            this.lrightpanel.PerformLayout();
            this.passwordarea.ResumeLayout(false);
            this.passwordarea.PerformLayout();
            this.usernamearea.ResumeLayout(false);
            this.usernamearea.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel lleftpanel;
        private System.Windows.Forms.Panel lrightpanel;
        private System.Windows.Forms.Panel passwordarea;
        private System.Windows.Forms.TextBox passwordbox;
        private System.Windows.Forms.Panel usernamearea;
        private System.Windows.Forms.Label Createnewacc;
        private System.Windows.Forms.Label logintoyouraccount1;
        private System.Windows.Forms.Label lEasyDine;
        private System.Windows.Forms.Button sclosebtn;
        private System.Windows.Forms.Label developername;
        private System.Windows.Forms.Label developedby;
        private System.Windows.Forms.Label support1;
        private System.Windows.Forms.Label support3;
        private System.Windows.Forms.Label support2;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label username;
        private System.Windows.Forms.Button forgetpasswordbtn;
        private System.Windows.Forms.Button loginbtn;
        private System.Windows.Forms.Label logintoyouraccount2;
        private System.Windows.Forms.TextBox usernamebox;
        private System.Windows.Forms.Button showpasswordbtn;
        private System.Windows.Forms.Button signupbtn;
    }
}

