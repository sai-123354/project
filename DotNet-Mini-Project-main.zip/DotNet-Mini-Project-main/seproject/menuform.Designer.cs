﻿namespace seproject
{
    partial class menuform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cartpanel = new System.Windows.Forms.Panel();
            this.billamountbox = new System.Windows.Forms.TextBox();
            this.taxbox = new System.Windows.Forms.TextBox();
            this.carttotalbox = new System.Windows.Forms.TextBox();
            this.datagridviewcart = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mcalculatebtn = new System.Windows.Forms.Button();
            this.mresetbtn = new System.Windows.Forms.Button();
            this.mgeneratereceiptbtn = new System.Windows.Forms.Button();
            this.mmycart = new System.Windows.Forms.Label();
            this.billamount = new System.Windows.Forms.Label();
            this.carttax = new System.Windows.Forms.Label();
            this.carttotal = new System.Windows.Forms.Label();
            this.mtoppanel = new System.Windows.Forms.Panel();
            this.mclosebtn = new System.Windows.Forms.Button();
            this.mmenu = new System.Windows.Forms.Label();
            this.mEasyDine = new System.Windows.Forms.Label();
            this.mcentrepanel = new System.Windows.Forms.Panel();
            this.chkveg = new System.Windows.Forms.CheckBox();
            this.beveragespanel = new System.Windows.Forms.Panel();
            this.qtydarjeelingtea = new System.Windows.Forms.NumericUpDown();
            this.qtymanhattan = new System.Windows.Forms.NumericUpDown();
            this.pricemanhattan = new System.Windows.Forms.Label();
            this.qtymallowginger = new System.Windows.Forms.NumericUpDown();
            this.pricedarjeelingtea = new System.Windows.Forms.Label();
            this.qtyespresso = new System.Windows.Forms.NumericUpDown();
            this.pricemallowginger = new System.Windows.Forms.Label();
            this.qtybombaysapphire = new System.Windows.Forms.NumericUpDown();
            this.priceespresso = new System.Windows.Forms.Label();
            this.pricebombaysapphire = new System.Windows.Forms.Label();
            this.chkmanhattan = new System.Windows.Forms.CheckBox();
            this.chkdarjeelingtea = new System.Windows.Forms.CheckBox();
            this.chkmallowginger = new System.Windows.Forms.CheckBox();
            this.chkespresso = new System.Windows.Forms.CheckBox();
            this.chkbombaysapphire = new System.Windows.Forms.CheckBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.snackspanel = new System.Windows.Forms.Panel();
            this.qtyfrenchbbqfries = new System.Windows.Forms.NumericUpDown();
            this.qtymexicandream = new System.Windows.Forms.NumericUpDown();
            this.pricemexicandream = new System.Windows.Forms.Label();
            this.qtycarbonara = new System.Windows.Forms.NumericUpDown();
            this.pricefrenchbbqfries = new System.Windows.Forms.Label();
            this.qtygcsandwich = new System.Windows.Forms.NumericUpDown();
            this.pricecarbonara = new System.Windows.Forms.Label();
            this.qtymcburger = new System.Windows.Forms.NumericUpDown();
            this.pricegcsandwich = new System.Windows.Forms.Label();
            this.pricemcburger = new System.Windows.Forms.Label();
            this.chkmexicandream = new System.Windows.Forms.CheckBox();
            this.chkfrenchbbqfries = new System.Windows.Forms.CheckBox();
            this.chkcarbonara = new System.Windows.Forms.CheckBox();
            this.chkgcsandwich = new System.Windows.Forms.CheckBox();
            this.chkmcburger = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.mainspanel = new System.Windows.Forms.Panel();
            this.qtybakedseabass = new System.Windows.Forms.NumericUpDown();
            this.qtypulledporksteak = new System.Windows.Forms.NumericUpDown();
            this.pricepulledporksteak = new System.Windows.Forms.Label();
            this.qtybraisedlamb = new System.Windows.Forms.NumericUpDown();
            this.pricebakedseabass = new System.Windows.Forms.Label();
            this.qtyricottavada = new System.Windows.Forms.NumericUpDown();
            this.pricebraisedlamb = new System.Windows.Forms.Label();
            this.qtypaneerkofta = new System.Windows.Forms.NumericUpDown();
            this.pricericottavada = new System.Windows.Forms.Label();
            this.pricepaneerkofta = new System.Windows.Forms.Label();
            this.chkpulledporksteak = new System.Windows.Forms.CheckBox();
            this.chkbakedseabass = new System.Windows.Forms.CheckBox();
            this.chkbraisedlamb = new System.Windows.Forms.CheckBox();
            this.chkricottavada = new System.Windows.Forms.CheckBox();
            this.chkpaneerkofta = new System.Windows.Forms.CheckBox();
            this.mainsqty = new System.Windows.Forms.Label();
            this.mainsprice = new System.Windows.Forms.Label();
            this.mains = new System.Windows.Forms.Label();
            this.appetizerspanel = new System.Windows.Forms.Panel();
            this.qtysemolinapuchkas = new System.Windows.Forms.NumericUpDown();
            this.qtymorelmusallam = new System.Windows.Forms.NumericUpDown();
            this.qtysmokedduck = new System.Windows.Forms.NumericUpDown();
            this.qtyroastmuttonboti = new System.Windows.Forms.NumericUpDown();
            this.chksemolinapuchkas = new System.Windows.Forms.CheckBox();
            this.qtypulledporktaco = new System.Windows.Forms.NumericUpDown();
            this.pricesemolinapuchkas = new System.Windows.Forms.Label();
            this.pricemorelmusallam = new System.Windows.Forms.Label();
            this.pricesmokedduck = new System.Windows.Forms.Label();
            this.priceroastmuttonboti = new System.Windows.Forms.Label();
            this.pricepulledporktaco = new System.Windows.Forms.Label();
            this.chkmorelmusallam = new System.Windows.Forms.CheckBox();
            this.chksmokedduck = new System.Windows.Forms.CheckBox();
            this.chkroastmuttonboti = new System.Windows.Forms.CheckBox();
            this.chkpulledporktaco = new System.Windows.Forms.CheckBox();
            this.appetizersqty = new System.Windows.Forms.Label();
            this.appetizersprice = new System.Windows.Forms.Label();
            this.appetizers = new System.Windows.Forms.Label();
            this.cartpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewcart)).BeginInit();
            this.mtoppanel.SuspendLayout();
            this.mcentrepanel.SuspendLayout();
            this.beveragespanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtydarjeelingtea)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymanhattan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymallowginger)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtyespresso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtybombaysapphire)).BeginInit();
            this.snackspanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtyfrenchbbqfries)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymexicandream)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtycarbonara)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtygcsandwich)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymcburger)).BeginInit();
            this.mainspanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtybakedseabass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtypulledporksteak)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtybraisedlamb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtyricottavada)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtypaneerkofta)).BeginInit();
            this.appetizerspanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtysemolinapuchkas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymorelmusallam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtysmokedduck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtyroastmuttonboti)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtypulledporktaco)).BeginInit();
            this.SuspendLayout();
            // 
            // cartpanel
            // 
            this.cartpanel.BackColor = System.Drawing.Color.Teal;
            this.cartpanel.Controls.Add(this.billamountbox);
            this.cartpanel.Controls.Add(this.taxbox);
            this.cartpanel.Controls.Add(this.carttotalbox);
            this.cartpanel.Controls.Add(this.datagridviewcart);
            this.cartpanel.Controls.Add(this.mcalculatebtn);
            this.cartpanel.Controls.Add(this.mresetbtn);
            this.cartpanel.Controls.Add(this.mgeneratereceiptbtn);
            this.cartpanel.Controls.Add(this.mmycart);
            this.cartpanel.Controls.Add(this.billamount);
            this.cartpanel.Controls.Add(this.carttax);
            this.cartpanel.Controls.Add(this.carttotal);
            this.cartpanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.cartpanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.cartpanel.Location = new System.Drawing.Point(1333, 86);
            this.cartpanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cartpanel.Name = "cartpanel";
            this.cartpanel.Size = new System.Drawing.Size(480, 884);
            this.cartpanel.TabIndex = 0;
            // 
            // billamountbox
            // 
            this.billamountbox.BackColor = System.Drawing.Color.White;
            this.billamountbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.billamountbox.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.billamountbox.ForeColor = System.Drawing.Color.Teal;
            this.billamountbox.Location = new System.Drawing.Point(236, 726);
            this.billamountbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.billamountbox.MaxLength = 30;
            this.billamountbox.Name = "billamountbox";
            this.billamountbox.ReadOnly = true;
            this.billamountbox.Size = new System.Drawing.Size(220, 37);
            this.billamountbox.TabIndex = 8;
            this.billamountbox.Text = "0.00 /- ";
            this.billamountbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // taxbox
            // 
            this.taxbox.BackColor = System.Drawing.Color.White;
            this.taxbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.taxbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.taxbox.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.taxbox.ForeColor = System.Drawing.Color.Teal;
            this.taxbox.Location = new System.Drawing.Point(380, 681);
            this.taxbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.taxbox.MaxLength = 30;
            this.taxbox.Name = "taxbox";
            this.taxbox.ReadOnly = true;
            this.taxbox.Size = new System.Drawing.Size(76, 37);
            this.taxbox.TabIndex = 8;
            this.taxbox.Text = "18%";
            this.taxbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // carttotalbox
            // 
            this.carttotalbox.BackColor = System.Drawing.Color.White;
            this.carttotalbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.carttotalbox.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carttotalbox.ForeColor = System.Drawing.Color.Teal;
            this.carttotalbox.Location = new System.Drawing.Point(236, 635);
            this.carttotalbox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.carttotalbox.MaxLength = 30;
            this.carttotalbox.Name = "carttotalbox";
            this.carttotalbox.ReadOnly = true;
            this.carttotalbox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.carttotalbox.Size = new System.Drawing.Size(220, 37);
            this.carttotalbox.TabIndex = 8;
            this.carttotalbox.Text = "0.00 /- ";
            this.carttotalbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // datagridviewcart
            // 
            this.datagridviewcart.AllowUserToAddRows = false;
            this.datagridviewcart.AllowUserToDeleteRows = false;
            this.datagridviewcart.AllowUserToResizeColumns = false;
            this.datagridviewcart.AllowUserToResizeRows = false;
            this.datagridviewcart.BackgroundColor = System.Drawing.Color.Gainsboro;
            this.datagridviewcart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.datagridviewcart.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.datagridviewcart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagridviewcart.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.datagridviewcart.Cursor = System.Windows.Forms.Cursors.Default;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.MediumSeaGreen;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.datagridviewcart.DefaultCellStyle = dataGridViewCellStyle1;
            this.datagridviewcart.Location = new System.Drawing.Point(23, 68);
            this.datagridviewcart.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.datagridviewcart.Name = "datagridviewcart";
            this.datagridviewcart.ReadOnly = true;
            this.datagridviewcart.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.datagridviewcart.RowHeadersWidth = 25;
            this.datagridviewcart.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.datagridviewcart.Size = new System.Drawing.Size(433, 474);
            this.datagridviewcart.TabIndex = 7;
            // 
            // Column1
            // 
            this.Column1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column1.Frozen = true;
            this.Column1.HeaderText = "Item Name";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            this.Column1.Width = 120;
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Column2.Frozen = true;
            this.Column2.HeaderText = "Item Quantity";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Width = 80;
            // 
            // Column3
            // 
            this.Column3.Frozen = true;
            this.Column3.HeaderText = "Item Total";
            this.Column3.MinimumWidth = 6;
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            this.Column3.Width = 125;
            // 
            // mcalculatebtn
            // 
            this.mcalculatebtn.BackColor = System.Drawing.Color.White;
            this.mcalculatebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mcalculatebtn.FlatAppearance.BorderSize = 0;
            this.mcalculatebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mcalculatebtn.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mcalculatebtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.mcalculatebtn.Location = new System.Drawing.Point(281, 583);
            this.mcalculatebtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mcalculatebtn.Name = "mcalculatebtn";
            this.mcalculatebtn.Size = new System.Drawing.Size(175, 44);
            this.mcalculatebtn.TabIndex = 6;
            this.mcalculatebtn.Text = "Calculate";
            this.mcalculatebtn.UseVisualStyleBackColor = false;
            this.mcalculatebtn.Click += new System.EventHandler(this.mcalculatebtn_Click);
            // 
            // mresetbtn
            // 
            this.mresetbtn.BackColor = System.Drawing.Color.White;
            this.mresetbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mresetbtn.FlatAppearance.BorderSize = 0;
            this.mresetbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mresetbtn.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mresetbtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.mresetbtn.Location = new System.Drawing.Point(28, 793);
            this.mresetbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mresetbtn.Name = "mresetbtn";
            this.mresetbtn.Size = new System.Drawing.Size(113, 44);
            this.mresetbtn.TabIndex = 6;
            this.mresetbtn.Text = "Reset";
            this.mresetbtn.UseVisualStyleBackColor = false;
            this.mresetbtn.Click += new System.EventHandler(this.mresetbtn_Click);
            // 
            // mgeneratereceiptbtn
            // 
            this.mgeneratereceiptbtn.BackColor = System.Drawing.Color.White;
            this.mgeneratereceiptbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mgeneratereceiptbtn.FlatAppearance.BorderSize = 0;
            this.mgeneratereceiptbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mgeneratereceiptbtn.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mgeneratereceiptbtn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.mgeneratereceiptbtn.Location = new System.Drawing.Point(160, 793);
            this.mgeneratereceiptbtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mgeneratereceiptbtn.Name = "mgeneratereceiptbtn";
            this.mgeneratereceiptbtn.Size = new System.Drawing.Size(296, 44);
            this.mgeneratereceiptbtn.TabIndex = 6;
            this.mgeneratereceiptbtn.Text = "Generate Receipt";
            this.mgeneratereceiptbtn.UseVisualStyleBackColor = false;
            this.mgeneratereceiptbtn.Click += new System.EventHandler(this.mgeneratereceiptbtn_Click);
            // 
            // mmycart
            // 
            this.mmycart.AutoSize = true;
            this.mmycart.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mmycart.ForeColor = System.Drawing.Color.White;
            this.mmycart.Location = new System.Drawing.Point(20, 12);
            this.mmycart.Margin = new System.Windows.Forms.Padding(0);
            this.mmycart.Name = "mmycart";
            this.mmycart.Size = new System.Drawing.Size(195, 50);
            this.mmycart.TabIndex = 0;
            this.mmycart.Text = "MY CART";
            // 
            // billamount
            // 
            this.billamount.AutoSize = true;
            this.billamount.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.billamount.ForeColor = System.Drawing.Color.White;
            this.billamount.Location = new System.Drawing.Point(20, 729);
            this.billamount.Margin = new System.Windows.Forms.Padding(0);
            this.billamount.Name = "billamount";
            this.billamount.Size = new System.Drawing.Size(193, 37);
            this.billamount.TabIndex = 0;
            this.billamount.Text = "Bill Amount :";
            // 
            // carttax
            // 
            this.carttax.AutoSize = true;
            this.carttax.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carttax.ForeColor = System.Drawing.Color.White;
            this.carttax.Location = new System.Drawing.Point(20, 683);
            this.carttax.Margin = new System.Windows.Forms.Padding(0);
            this.carttax.Name = "carttax";
            this.carttax.Size = new System.Drawing.Size(83, 37);
            this.carttax.TabIndex = 0;
            this.carttax.Text = "Tax :";
            // 
            // carttotal
            // 
            this.carttotal.AutoSize = true;
            this.carttotal.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.carttotal.ForeColor = System.Drawing.Color.White;
            this.carttotal.Location = new System.Drawing.Point(20, 638);
            this.carttotal.Margin = new System.Windows.Forms.Padding(0);
            this.carttotal.Name = "carttotal";
            this.carttotal.Size = new System.Drawing.Size(171, 37);
            this.carttotal.TabIndex = 0;
            this.carttotal.Text = "Cart Total :";
            // 
            // mtoppanel
            // 
            this.mtoppanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.mtoppanel.Controls.Add(this.mclosebtn);
            this.mtoppanel.Controls.Add(this.mmenu);
            this.mtoppanel.Controls.Add(this.mEasyDine);
            this.mtoppanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.mtoppanel.Location = new System.Drawing.Point(0, 0);
            this.mtoppanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mtoppanel.Name = "mtoppanel";
            this.mtoppanel.Size = new System.Drawing.Size(1813, 86);
            this.mtoppanel.TabIndex = 1;
            // 
            // mclosebtn
            // 
            this.mclosebtn.BackColor = System.Drawing.Color.Transparent;
            this.mclosebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mclosebtn.Dock = System.Windows.Forms.DockStyle.Right;
            this.mclosebtn.FlatAppearance.BorderSize = 0;
            this.mclosebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mclosebtn.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mclosebtn.ForeColor = System.Drawing.Color.White;
            this.mclosebtn.Location = new System.Drawing.Point(1762, 0);
            this.mclosebtn.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mclosebtn.Name = "mclosebtn";
            this.mclosebtn.Size = new System.Drawing.Size(51, 86);
            this.mclosebtn.TabIndex = 4;
            this.mclosebtn.Text = "X";
            this.mclosebtn.UseVisualStyleBackColor = false;
            this.mclosebtn.Click += new System.EventHandler(this.mclosebtn_Click);
            this.mclosebtn.MouseEnter += new System.EventHandler(this.mclosebtn_MouseEnter);
            this.mclosebtn.MouseLeave += new System.EventHandler(this.mclosebtn_MouseLeave);
            // 
            // mmenu
            // 
            this.mmenu.AutoSize = true;
            this.mmenu.Font = new System.Drawing.Font("Century Gothic", 30F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mmenu.ForeColor = System.Drawing.SystemColors.Control;
            this.mmenu.Location = new System.Drawing.Point(820, 15);
            this.mmenu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.mmenu.Name = "mmenu";
            this.mmenu.Size = new System.Drawing.Size(164, 60);
            this.mmenu.TabIndex = 1;
            this.mmenu.Text = "Menu";
            // 
            // mEasyDine
            // 
            this.mEasyDine.AutoSize = true;
            this.mEasyDine.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mEasyDine.Font = new System.Drawing.Font("Verdana", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mEasyDine.ForeColor = System.Drawing.SystemColors.Control;
            this.mEasyDine.Location = new System.Drawing.Point(7, 4);
            this.mEasyDine.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.mEasyDine.Name = "mEasyDine";
            this.mEasyDine.Size = new System.Drawing.Size(120, 32);
            this.mEasyDine.TabIndex = 1;
            this.mEasyDine.Text = "<BACK";
            this.mEasyDine.Click += new System.EventHandler(this.mEasyDine_Click);
            this.mEasyDine.MouseEnter += new System.EventHandler(this.mEasyDine_MouseEnter);
            this.mEasyDine.MouseLeave += new System.EventHandler(this.mEasyDine_MouseLeave);
            // 
            // mcentrepanel
            // 
            this.mcentrepanel.BackColor = System.Drawing.Color.Gainsboro;
            this.mcentrepanel.Controls.Add(this.chkveg);
            this.mcentrepanel.Controls.Add(this.beveragespanel);
            this.mcentrepanel.Controls.Add(this.snackspanel);
            this.mcentrepanel.Controls.Add(this.mainspanel);
            this.mcentrepanel.Controls.Add(this.appetizerspanel);
            this.mcentrepanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mcentrepanel.Location = new System.Drawing.Point(0, 86);
            this.mcentrepanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mcentrepanel.Name = "mcentrepanel";
            this.mcentrepanel.Size = new System.Drawing.Size(1333, 884);
            this.mcentrepanel.TabIndex = 2;
            // 
            // chkveg
            // 
            this.chkveg.AutoSize = true;
            this.chkveg.BackColor = System.Drawing.Color.Teal;
            this.chkveg.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.chkveg.Font = new System.Drawing.Font("Century Gothic", 16F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkveg.ForeColor = System.Drawing.Color.White;
            this.chkveg.Location = new System.Drawing.Point(568, 796);
            this.chkveg.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkveg.Name = "chkveg";
            this.chkveg.Padding = new System.Windows.Forms.Padding(13, 2, 3, 2);
            this.chkveg.Size = new System.Drawing.Size(185, 41);
            this.chkveg.TabIndex = 1;
            this.chkveg.Text = "VEG ONLY";
            this.chkveg.UseVisualStyleBackColor = false;
            this.chkveg.CheckedChanged += new System.EventHandler(this.chkveg_CheckedChanged);
            // 
            // beveragespanel
            // 
            this.beveragespanel.BackColor = System.Drawing.Color.Teal;
            this.beveragespanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.beveragespanel.Controls.Add(this.qtydarjeelingtea);
            this.beveragespanel.Controls.Add(this.qtymanhattan);
            this.beveragespanel.Controls.Add(this.pricemanhattan);
            this.beveragespanel.Controls.Add(this.qtymallowginger);
            this.beveragespanel.Controls.Add(this.pricedarjeelingtea);
            this.beveragespanel.Controls.Add(this.qtyespresso);
            this.beveragespanel.Controls.Add(this.pricemallowginger);
            this.beveragespanel.Controls.Add(this.qtybombaysapphire);
            this.beveragespanel.Controls.Add(this.priceespresso);
            this.beveragespanel.Controls.Add(this.pricebombaysapphire);
            this.beveragespanel.Controls.Add(this.chkmanhattan);
            this.beveragespanel.Controls.Add(this.chkdarjeelingtea);
            this.beveragespanel.Controls.Add(this.chkmallowginger);
            this.beveragespanel.Controls.Add(this.chkespresso);
            this.beveragespanel.Controls.Add(this.chkbombaysapphire);
            this.beveragespanel.Controls.Add(this.label27);
            this.beveragespanel.Controls.Add(this.label28);
            this.beveragespanel.Controls.Add(this.label29);
            this.beveragespanel.Location = new System.Drawing.Point(673, 394);
            this.beveragespanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.beveragespanel.Name = "beveragespanel";
            this.beveragespanel.Size = new System.Drawing.Size(645, 368);
            this.beveragespanel.TabIndex = 0;
            // 
            // qtydarjeelingtea
            // 
            this.qtydarjeelingtea.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtydarjeelingtea.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtydarjeelingtea.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtydarjeelingtea.Enabled = false;
            this.qtydarjeelingtea.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtydarjeelingtea.ForeColor = System.Drawing.Color.White;
            this.qtydarjeelingtea.Location = new System.Drawing.Point(411, 249);
            this.qtydarjeelingtea.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtydarjeelingtea.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtydarjeelingtea.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtydarjeelingtea.Name = "qtydarjeelingtea";
            this.qtydarjeelingtea.Size = new System.Drawing.Size(61, 36);
            this.qtydarjeelingtea.TabIndex = 10;
            this.qtydarjeelingtea.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtydarjeelingtea.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtydarjeelingtea.ValueChanged += new System.EventHandler(this.qtydarjeelingtea_ValueChanged);
            // 
            // qtymanhattan
            // 
            this.qtymanhattan.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtymanhattan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtymanhattan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtymanhattan.Enabled = false;
            this.qtymanhattan.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtymanhattan.ForeColor = System.Drawing.Color.White;
            this.qtymanhattan.Location = new System.Drawing.Point(411, 308);
            this.qtymanhattan.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtymanhattan.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtymanhattan.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymanhattan.Name = "qtymanhattan";
            this.qtymanhattan.Size = new System.Drawing.Size(61, 36);
            this.qtymanhattan.TabIndex = 11;
            this.qtymanhattan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtymanhattan.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymanhattan.ValueChanged += new System.EventHandler(this.qtymanhattan_ValueChanged);
            // 
            // pricemanhattan
            // 
            this.pricemanhattan.AutoSize = true;
            this.pricemanhattan.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricemanhattan.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricemanhattan.ForeColor = System.Drawing.Color.White;
            this.pricemanhattan.Location = new System.Drawing.Point(527, 306);
            this.pricemanhattan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricemanhattan.Name = "pricemanhattan";
            this.pricemanhattan.Size = new System.Drawing.Size(93, 39);
            this.pricemanhattan.TabIndex = 3;
            this.pricemanhattan.Text = "1200";
            // 
            // qtymallowginger
            // 
            this.qtymallowginger.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtymallowginger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtymallowginger.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtymallowginger.Enabled = false;
            this.qtymallowginger.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtymallowginger.ForeColor = System.Drawing.Color.White;
            this.qtymallowginger.Location = new System.Drawing.Point(411, 190);
            this.qtymallowginger.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtymallowginger.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtymallowginger.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymallowginger.Name = "qtymallowginger";
            this.qtymallowginger.Size = new System.Drawing.Size(61, 36);
            this.qtymallowginger.TabIndex = 12;
            this.qtymallowginger.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtymallowginger.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymallowginger.ValueChanged += new System.EventHandler(this.qtymallowginger_ValueChanged);
            // 
            // pricedarjeelingtea
            // 
            this.pricedarjeelingtea.AutoSize = true;
            this.pricedarjeelingtea.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricedarjeelingtea.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricedarjeelingtea.ForeColor = System.Drawing.Color.White;
            this.pricedarjeelingtea.Location = new System.Drawing.Point(547, 247);
            this.pricedarjeelingtea.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricedarjeelingtea.Name = "pricedarjeelingtea";
            this.pricedarjeelingtea.Size = new System.Drawing.Size(74, 39);
            this.pricedarjeelingtea.TabIndex = 3;
            this.pricedarjeelingtea.Text = "220";
            // 
            // qtyespresso
            // 
            this.qtyespresso.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtyespresso.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtyespresso.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtyespresso.Enabled = false;
            this.qtyespresso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtyespresso.ForeColor = System.Drawing.Color.White;
            this.qtyespresso.Location = new System.Drawing.Point(411, 130);
            this.qtyespresso.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtyespresso.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtyespresso.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtyespresso.Name = "qtyespresso";
            this.qtyespresso.Size = new System.Drawing.Size(61, 36);
            this.qtyespresso.TabIndex = 13;
            this.qtyespresso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtyespresso.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtyespresso.ValueChanged += new System.EventHandler(this.qtyespresso_ValueChanged);
            // 
            // pricemallowginger
            // 
            this.pricemallowginger.AutoSize = true;
            this.pricemallowginger.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricemallowginger.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricemallowginger.ForeColor = System.Drawing.Color.White;
            this.pricemallowginger.Location = new System.Drawing.Point(547, 188);
            this.pricemallowginger.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricemallowginger.Name = "pricemallowginger";
            this.pricemallowginger.Size = new System.Drawing.Size(74, 39);
            this.pricemallowginger.TabIndex = 3;
            this.pricemallowginger.Text = "280";
            // 
            // qtybombaysapphire
            // 
            this.qtybombaysapphire.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtybombaysapphire.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtybombaysapphire.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtybombaysapphire.Enabled = false;
            this.qtybombaysapphire.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtybombaysapphire.ForeColor = System.Drawing.Color.White;
            this.qtybombaysapphire.Location = new System.Drawing.Point(411, 71);
            this.qtybombaysapphire.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtybombaysapphire.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtybombaysapphire.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtybombaysapphire.Name = "qtybombaysapphire";
            this.qtybombaysapphire.Size = new System.Drawing.Size(61, 36);
            this.qtybombaysapphire.TabIndex = 14;
            this.qtybombaysapphire.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtybombaysapphire.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtybombaysapphire.ValueChanged += new System.EventHandler(this.qtybombaysapphire_ValueChanged);
            // 
            // priceespresso
            // 
            this.priceespresso.AutoSize = true;
            this.priceespresso.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.priceespresso.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priceespresso.ForeColor = System.Drawing.Color.White;
            this.priceespresso.Location = new System.Drawing.Point(547, 129);
            this.priceespresso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.priceespresso.Name = "priceespresso";
            this.priceespresso.Size = new System.Drawing.Size(74, 39);
            this.priceespresso.TabIndex = 3;
            this.priceespresso.Text = "450";
            // 
            // pricebombaysapphire
            // 
            this.pricebombaysapphire.AutoSize = true;
            this.pricebombaysapphire.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricebombaysapphire.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricebombaysapphire.ForeColor = System.Drawing.Color.White;
            this.pricebombaysapphire.Location = new System.Drawing.Point(547, 70);
            this.pricebombaysapphire.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricebombaysapphire.Name = "pricebombaysapphire";
            this.pricebombaysapphire.Size = new System.Drawing.Size(74, 39);
            this.pricebombaysapphire.TabIndex = 3;
            this.pricebombaysapphire.Text = "650";
            // 
            // chkmanhattan
            // 
            this.chkmanhattan.AutoSize = true;
            this.chkmanhattan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkmanhattan.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkmanhattan.ForeColor = System.Drawing.Color.White;
            this.chkmanhattan.Location = new System.Drawing.Point(8, 304);
            this.chkmanhattan.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkmanhattan.Name = "chkmanhattan";
            this.chkmanhattan.Size = new System.Drawing.Size(298, 44);
            this.chkmanhattan.TabIndex = 1;
            this.chkmanhattan.Text = "Manhattan        ";
            this.chkmanhattan.UseVisualStyleBackColor = true;
            this.chkmanhattan.CheckedChanged += new System.EventHandler(this.chkmanhattan_CheckedChanged);
            // 
            // chkdarjeelingtea
            // 
            this.chkdarjeelingtea.AutoSize = true;
            this.chkdarjeelingtea.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkdarjeelingtea.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkdarjeelingtea.ForeColor = System.Drawing.Color.White;
            this.chkdarjeelingtea.Location = new System.Drawing.Point(8, 245);
            this.chkdarjeelingtea.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkdarjeelingtea.Name = "chkdarjeelingtea";
            this.chkdarjeelingtea.Size = new System.Drawing.Size(299, 44);
            this.chkdarjeelingtea.TabIndex = 1;
            this.chkdarjeelingtea.Text = "Darjeeling Tea   ";
            this.chkdarjeelingtea.UseVisualStyleBackColor = true;
            this.chkdarjeelingtea.CheckedChanged += new System.EventHandler(this.chkdarjeelingtea_CheckedChanged);
            // 
            // chkmallowginger
            // 
            this.chkmallowginger.AutoSize = true;
            this.chkmallowginger.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkmallowginger.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkmallowginger.ForeColor = System.Drawing.Color.White;
            this.chkmallowginger.Location = new System.Drawing.Point(8, 186);
            this.chkmallowginger.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkmallowginger.Name = "chkmallowginger";
            this.chkmallowginger.Size = new System.Drawing.Size(313, 44);
            this.chkmallowginger.TabIndex = 1;
            this.chkmallowginger.Text = "Mallow Ginger    ";
            this.chkmallowginger.UseVisualStyleBackColor = true;
            this.chkmallowginger.CheckedChanged += new System.EventHandler(this.chkmallowginger_CheckedChanged);
            // 
            // chkespresso
            // 
            this.chkespresso.AutoSize = true;
            this.chkespresso.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkespresso.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkespresso.ForeColor = System.Drawing.Color.White;
            this.chkespresso.Location = new System.Drawing.Point(8, 127);
            this.chkespresso.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkespresso.Name = "chkespresso";
            this.chkespresso.Size = new System.Drawing.Size(254, 44);
            this.chkespresso.TabIndex = 1;
            this.chkespresso.Text = "Espresso         ";
            this.chkespresso.UseVisualStyleBackColor = true;
            this.chkespresso.CheckedChanged += new System.EventHandler(this.chkespresso_CheckedChanged);
            // 
            // chkbombaysapphire
            // 
            this.chkbombaysapphire.AutoSize = true;
            this.chkbombaysapphire.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkbombaysapphire.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbombaysapphire.ForeColor = System.Drawing.Color.White;
            this.chkbombaysapphire.Location = new System.Drawing.Point(8, 68);
            this.chkbombaysapphire.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkbombaysapphire.Name = "chkbombaysapphire";
            this.chkbombaysapphire.Size = new System.Drawing.Size(349, 44);
            this.chkbombaysapphire.TabIndex = 1;
            this.chkbombaysapphire.Text = "Bombay Sapphire  ";
            this.chkbombaysapphire.UseVisualStyleBackColor = true;
            this.chkbombaysapphire.CheckedChanged += new System.EventHandler(this.chkbombaysapphire_CheckedChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(401, 0);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(91, 50);
            this.label27.TabIndex = 0;
            this.label27.Text = "Qty";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(517, 0);
            this.label28.Margin = new System.Windows.Forms.Padding(0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(119, 50);
            this.label28.TabIndex = 0;
            this.label28.Text = "Price";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(-1, 0);
            this.label29.Margin = new System.Windows.Forms.Padding(0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(244, 50);
            this.label29.TabIndex = 0;
            this.label29.Text = "BEVERAGES";
            // 
            // snackspanel
            // 
            this.snackspanel.BackColor = System.Drawing.Color.Teal;
            this.snackspanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.snackspanel.Controls.Add(this.qtyfrenchbbqfries);
            this.snackspanel.Controls.Add(this.qtymexicandream);
            this.snackspanel.Controls.Add(this.pricemexicandream);
            this.snackspanel.Controls.Add(this.qtycarbonara);
            this.snackspanel.Controls.Add(this.pricefrenchbbqfries);
            this.snackspanel.Controls.Add(this.qtygcsandwich);
            this.snackspanel.Controls.Add(this.pricecarbonara);
            this.snackspanel.Controls.Add(this.qtymcburger);
            this.snackspanel.Controls.Add(this.pricegcsandwich);
            this.snackspanel.Controls.Add(this.pricemcburger);
            this.snackspanel.Controls.Add(this.chkmexicandream);
            this.snackspanel.Controls.Add(this.chkfrenchbbqfries);
            this.snackspanel.Controls.Add(this.chkcarbonara);
            this.snackspanel.Controls.Add(this.chkgcsandwich);
            this.snackspanel.Controls.Add(this.chkmcburger);
            this.snackspanel.Controls.Add(this.label11);
            this.snackspanel.Controls.Add(this.label12);
            this.snackspanel.Controls.Add(this.label13);
            this.snackspanel.Location = new System.Drawing.Point(13, 394);
            this.snackspanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.snackspanel.Name = "snackspanel";
            this.snackspanel.Size = new System.Drawing.Size(645, 368);
            this.snackspanel.TabIndex = 0;
            // 
            // qtyfrenchbbqfries
            // 
            this.qtyfrenchbbqfries.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtyfrenchbbqfries.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtyfrenchbbqfries.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtyfrenchbbqfries.Enabled = false;
            this.qtyfrenchbbqfries.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtyfrenchbbqfries.ForeColor = System.Drawing.Color.White;
            this.qtyfrenchbbqfries.Location = new System.Drawing.Point(411, 249);
            this.qtyfrenchbbqfries.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtyfrenchbbqfries.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtyfrenchbbqfries.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtyfrenchbbqfries.Name = "qtyfrenchbbqfries";
            this.qtyfrenchbbqfries.Size = new System.Drawing.Size(61, 36);
            this.qtyfrenchbbqfries.TabIndex = 5;
            this.qtyfrenchbbqfries.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtyfrenchbbqfries.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtyfrenchbbqfries.ValueChanged += new System.EventHandler(this.qtyfrenchbbqfries_ValueChanged);
            // 
            // qtymexicandream
            // 
            this.qtymexicandream.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtymexicandream.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtymexicandream.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtymexicandream.Enabled = false;
            this.qtymexicandream.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtymexicandream.ForeColor = System.Drawing.Color.White;
            this.qtymexicandream.Location = new System.Drawing.Point(411, 308);
            this.qtymexicandream.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtymexicandream.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtymexicandream.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymexicandream.Name = "qtymexicandream";
            this.qtymexicandream.Size = new System.Drawing.Size(61, 36);
            this.qtymexicandream.TabIndex = 6;
            this.qtymexicandream.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtymexicandream.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymexicandream.ValueChanged += new System.EventHandler(this.qtymexicandream_ValueChanged);
            // 
            // pricemexicandream
            // 
            this.pricemexicandream.AutoSize = true;
            this.pricemexicandream.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricemexicandream.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricemexicandream.ForeColor = System.Drawing.Color.White;
            this.pricemexicandream.Location = new System.Drawing.Point(544, 306);
            this.pricemexicandream.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricemexicandream.Name = "pricemexicandream";
            this.pricemexicandream.Size = new System.Drawing.Size(74, 39);
            this.pricemexicandream.TabIndex = 3;
            this.pricemexicandream.Text = "250";
            // 
            // qtycarbonara
            // 
            this.qtycarbonara.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtycarbonara.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtycarbonara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtycarbonara.Enabled = false;
            this.qtycarbonara.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtycarbonara.ForeColor = System.Drawing.Color.White;
            this.qtycarbonara.Location = new System.Drawing.Point(411, 190);
            this.qtycarbonara.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtycarbonara.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtycarbonara.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtycarbonara.Name = "qtycarbonara";
            this.qtycarbonara.Size = new System.Drawing.Size(61, 36);
            this.qtycarbonara.TabIndex = 7;
            this.qtycarbonara.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtycarbonara.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtycarbonara.ValueChanged += new System.EventHandler(this.qtycarbonara_ValueChanged);
            // 
            // pricefrenchbbqfries
            // 
            this.pricefrenchbbqfries.AutoSize = true;
            this.pricefrenchbbqfries.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricefrenchbbqfries.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricefrenchbbqfries.ForeColor = System.Drawing.Color.White;
            this.pricefrenchbbqfries.Location = new System.Drawing.Point(544, 249);
            this.pricefrenchbbqfries.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricefrenchbbqfries.Name = "pricefrenchbbqfries";
            this.pricefrenchbbqfries.Size = new System.Drawing.Size(74, 39);
            this.pricefrenchbbqfries.TabIndex = 3;
            this.pricefrenchbbqfries.Text = "250";
            // 
            // qtygcsandwich
            // 
            this.qtygcsandwich.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtygcsandwich.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtygcsandwich.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtygcsandwich.Enabled = false;
            this.qtygcsandwich.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtygcsandwich.ForeColor = System.Drawing.Color.White;
            this.qtygcsandwich.Location = new System.Drawing.Point(411, 130);
            this.qtygcsandwich.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtygcsandwich.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtygcsandwich.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtygcsandwich.Name = "qtygcsandwich";
            this.qtygcsandwich.Size = new System.Drawing.Size(61, 36);
            this.qtygcsandwich.TabIndex = 8;
            this.qtygcsandwich.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtygcsandwich.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtygcsandwich.ValueChanged += new System.EventHandler(this.qtygcsandwich_ValueChanged);
            // 
            // pricecarbonara
            // 
            this.pricecarbonara.AutoSize = true;
            this.pricecarbonara.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricecarbonara.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricecarbonara.ForeColor = System.Drawing.Color.White;
            this.pricecarbonara.Location = new System.Drawing.Point(544, 190);
            this.pricecarbonara.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricecarbonara.Name = "pricecarbonara";
            this.pricecarbonara.Size = new System.Drawing.Size(74, 39);
            this.pricecarbonara.TabIndex = 3;
            this.pricecarbonara.Text = "400";
            // 
            // qtymcburger
            // 
            this.qtymcburger.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtymcburger.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtymcburger.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtymcburger.Enabled = false;
            this.qtymcburger.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtymcburger.ForeColor = System.Drawing.Color.White;
            this.qtymcburger.Location = new System.Drawing.Point(411, 71);
            this.qtymcburger.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtymcburger.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtymcburger.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymcburger.Name = "qtymcburger";
            this.qtymcburger.Size = new System.Drawing.Size(61, 36);
            this.qtymcburger.TabIndex = 9;
            this.qtymcburger.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtymcburger.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymcburger.ValueChanged += new System.EventHandler(this.qtymcburger_ValueChanged);
            // 
            // pricegcsandwich
            // 
            this.pricegcsandwich.AutoSize = true;
            this.pricegcsandwich.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricegcsandwich.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricegcsandwich.ForeColor = System.Drawing.Color.White;
            this.pricegcsandwich.Location = new System.Drawing.Point(544, 130);
            this.pricegcsandwich.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricegcsandwich.Name = "pricegcsandwich";
            this.pricegcsandwich.Size = new System.Drawing.Size(74, 39);
            this.pricegcsandwich.TabIndex = 3;
            this.pricegcsandwich.Text = "180";
            // 
            // pricemcburger
            // 
            this.pricemcburger.AutoSize = true;
            this.pricemcburger.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricemcburger.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricemcburger.ForeColor = System.Drawing.Color.White;
            this.pricemcburger.Location = new System.Drawing.Point(544, 71);
            this.pricemcburger.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricemcburger.Name = "pricemcburger";
            this.pricemcburger.Size = new System.Drawing.Size(74, 39);
            this.pricemcburger.TabIndex = 3;
            this.pricemcburger.Text = "350";
            // 
            // chkmexicandream
            // 
            this.chkmexicandream.AutoSize = true;
            this.chkmexicandream.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkmexicandream.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkmexicandream.ForeColor = System.Drawing.Color.White;
            this.chkmexicandream.Location = new System.Drawing.Point(8, 304);
            this.chkmexicandream.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkmexicandream.Name = "chkmexicandream";
            this.chkmexicandream.Size = new System.Drawing.Size(336, 44);
            this.chkmexicandream.TabIndex = 1;
            this.chkmexicandream.Text = "Mexican Dream    ";
            this.chkmexicandream.UseVisualStyleBackColor = true;
            this.chkmexicandream.CheckedChanged += new System.EventHandler(this.chkmexicandream_CheckedChanged);
            // 
            // chkfrenchbbqfries
            // 
            this.chkfrenchbbqfries.AutoSize = true;
            this.chkfrenchbbqfries.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkfrenchbbqfries.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkfrenchbbqfries.ForeColor = System.Drawing.Color.White;
            this.chkfrenchbbqfries.Location = new System.Drawing.Point(8, 245);
            this.chkfrenchbbqfries.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkfrenchbbqfries.Name = "chkfrenchbbqfries";
            this.chkfrenchbbqfries.Size = new System.Drawing.Size(316, 44);
            this.chkfrenchbbqfries.TabIndex = 1;
            this.chkfrenchbbqfries.Text = "French BBQ Fries ";
            this.chkfrenchbbqfries.UseVisualStyleBackColor = true;
            this.chkfrenchbbqfries.CheckedChanged += new System.EventHandler(this.chkfrenchbbqfries_CheckedChanged);
            // 
            // chkcarbonara
            // 
            this.chkcarbonara.AutoSize = true;
            this.chkcarbonara.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkcarbonara.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkcarbonara.ForeColor = System.Drawing.Color.White;
            this.chkcarbonara.Location = new System.Drawing.Point(8, 186);
            this.chkcarbonara.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkcarbonara.Name = "chkcarbonara";
            this.chkcarbonara.Size = new System.Drawing.Size(294, 44);
            this.chkcarbonara.TabIndex = 1;
            this.chkcarbonara.Text = "Carbonara        ";
            this.chkcarbonara.UseVisualStyleBackColor = true;
            this.chkcarbonara.CheckedChanged += new System.EventHandler(this.chkcarbonara_CheckedChanged);
            // 
            // chkgcsandwich
            // 
            this.chkgcsandwich.AutoSize = true;
            this.chkgcsandwich.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkgcsandwich.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkgcsandwich.ForeColor = System.Drawing.Color.White;
            this.chkgcsandwich.Location = new System.Drawing.Point(8, 127);
            this.chkgcsandwich.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkgcsandwich.Name = "chkgcsandwich";
            this.chkgcsandwich.Size = new System.Drawing.Size(322, 44);
            this.chkgcsandwich.TabIndex = 1;
            this.chkgcsandwich.Text = "G C Sandwich     ";
            this.chkgcsandwich.UseVisualStyleBackColor = true;
            this.chkgcsandwich.CheckedChanged += new System.EventHandler(this.chkgcsandwich_CheckedChanged);
            // 
            // chkmcburger
            // 
            this.chkmcburger.AutoSize = true;
            this.chkmcburger.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkmcburger.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkmcburger.ForeColor = System.Drawing.Color.White;
            this.chkmcburger.Location = new System.Drawing.Point(8, 68);
            this.chkmcburger.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkmcburger.Name = "chkmcburger";
            this.chkmcburger.Size = new System.Drawing.Size(285, 44);
            this.chkmcburger.TabIndex = 1;
            this.chkmcburger.Text = "M C Burger       ";
            this.chkmcburger.UseVisualStyleBackColor = true;
            this.chkmcburger.CheckedChanged += new System.EventHandler(this.chkmcburger_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(401, 0);
            this.label11.Margin = new System.Windows.Forms.Padding(0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(91, 50);
            this.label11.TabIndex = 0;
            this.label11.Text = "Qty";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(517, 0);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(119, 50);
            this.label12.TabIndex = 0;
            this.label12.Text = "Price";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(-1, 0);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(180, 50);
            this.label13.TabIndex = 0;
            this.label13.Text = "SNACKS";
            // 
            // mainspanel
            // 
            this.mainspanel.BackColor = System.Drawing.Color.Teal;
            this.mainspanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mainspanel.Controls.Add(this.qtybakedseabass);
            this.mainspanel.Controls.Add(this.qtypulledporksteak);
            this.mainspanel.Controls.Add(this.pricepulledporksteak);
            this.mainspanel.Controls.Add(this.qtybraisedlamb);
            this.mainspanel.Controls.Add(this.pricebakedseabass);
            this.mainspanel.Controls.Add(this.qtyricottavada);
            this.mainspanel.Controls.Add(this.pricebraisedlamb);
            this.mainspanel.Controls.Add(this.qtypaneerkofta);
            this.mainspanel.Controls.Add(this.pricericottavada);
            this.mainspanel.Controls.Add(this.pricepaneerkofta);
            this.mainspanel.Controls.Add(this.chkpulledporksteak);
            this.mainspanel.Controls.Add(this.chkbakedseabass);
            this.mainspanel.Controls.Add(this.chkbraisedlamb);
            this.mainspanel.Controls.Add(this.chkricottavada);
            this.mainspanel.Controls.Add(this.chkpaneerkofta);
            this.mainspanel.Controls.Add(this.mainsqty);
            this.mainspanel.Controls.Add(this.mainsprice);
            this.mainspanel.Controls.Add(this.mains);
            this.mainspanel.Location = new System.Drawing.Point(673, 12);
            this.mainspanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.mainspanel.Name = "mainspanel";
            this.mainspanel.Size = new System.Drawing.Size(645, 368);
            this.mainspanel.TabIndex = 0;
            // 
            // qtybakedseabass
            // 
            this.qtybakedseabass.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtybakedseabass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtybakedseabass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtybakedseabass.Enabled = false;
            this.qtybakedseabass.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtybakedseabass.ForeColor = System.Drawing.Color.White;
            this.qtybakedseabass.Location = new System.Drawing.Point(411, 249);
            this.qtybakedseabass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtybakedseabass.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtybakedseabass.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtybakedseabass.Name = "qtybakedseabass";
            this.qtybakedseabass.Size = new System.Drawing.Size(61, 36);
            this.qtybakedseabass.TabIndex = 5;
            this.qtybakedseabass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtybakedseabass.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtybakedseabass.ValueChanged += new System.EventHandler(this.qtybakedseabass_ValueChanged);
            // 
            // qtypulledporksteak
            // 
            this.qtypulledporksteak.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtypulledporksteak.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtypulledporksteak.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtypulledporksteak.Enabled = false;
            this.qtypulledporksteak.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtypulledporksteak.ForeColor = System.Drawing.Color.White;
            this.qtypulledporksteak.Location = new System.Drawing.Point(411, 308);
            this.qtypulledporksteak.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtypulledporksteak.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtypulledporksteak.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtypulledporksteak.Name = "qtypulledporksteak";
            this.qtypulledporksteak.Size = new System.Drawing.Size(61, 36);
            this.qtypulledporksteak.TabIndex = 6;
            this.qtypulledporksteak.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtypulledporksteak.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtypulledporksteak.ValueChanged += new System.EventHandler(this.qtypulledporksteak_ValueChanged);
            // 
            // pricepulledporksteak
            // 
            this.pricepulledporksteak.AutoSize = true;
            this.pricepulledporksteak.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricepulledporksteak.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricepulledporksteak.ForeColor = System.Drawing.Color.White;
            this.pricepulledporksteak.Location = new System.Drawing.Point(524, 308);
            this.pricepulledporksteak.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricepulledporksteak.Name = "pricepulledporksteak";
            this.pricepulledporksteak.Size = new System.Drawing.Size(93, 39);
            this.pricepulledporksteak.TabIndex = 3;
            this.pricepulledporksteak.Text = "1550";
            // 
            // qtybraisedlamb
            // 
            this.qtybraisedlamb.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtybraisedlamb.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtybraisedlamb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtybraisedlamb.Enabled = false;
            this.qtybraisedlamb.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtybraisedlamb.ForeColor = System.Drawing.Color.White;
            this.qtybraisedlamb.Location = new System.Drawing.Point(411, 190);
            this.qtybraisedlamb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtybraisedlamb.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtybraisedlamb.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtybraisedlamb.Name = "qtybraisedlamb";
            this.qtybraisedlamb.Size = new System.Drawing.Size(61, 36);
            this.qtybraisedlamb.TabIndex = 7;
            this.qtybraisedlamb.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtybraisedlamb.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtybraisedlamb.ValueChanged += new System.EventHandler(this.qtybraisedlamb_ValueChanged);
            // 
            // pricebakedseabass
            // 
            this.pricebakedseabass.AutoSize = true;
            this.pricebakedseabass.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricebakedseabass.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricebakedseabass.ForeColor = System.Drawing.Color.White;
            this.pricebakedseabass.Location = new System.Drawing.Point(524, 249);
            this.pricebakedseabass.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricebakedseabass.Name = "pricebakedseabass";
            this.pricebakedseabass.Size = new System.Drawing.Size(93, 39);
            this.pricebakedseabass.TabIndex = 3;
            this.pricebakedseabass.Text = "1700";
            // 
            // qtyricottavada
            // 
            this.qtyricottavada.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtyricottavada.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtyricottavada.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtyricottavada.Enabled = false;
            this.qtyricottavada.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtyricottavada.ForeColor = System.Drawing.Color.White;
            this.qtyricottavada.Location = new System.Drawing.Point(411, 130);
            this.qtyricottavada.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtyricottavada.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtyricottavada.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtyricottavada.Name = "qtyricottavada";
            this.qtyricottavada.Size = new System.Drawing.Size(61, 36);
            this.qtyricottavada.TabIndex = 8;
            this.qtyricottavada.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtyricottavada.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtyricottavada.ValueChanged += new System.EventHandler(this.qtyricottavada_ValueChanged);
            // 
            // pricebraisedlamb
            // 
            this.pricebraisedlamb.AutoSize = true;
            this.pricebraisedlamb.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricebraisedlamb.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricebraisedlamb.ForeColor = System.Drawing.Color.White;
            this.pricebraisedlamb.Location = new System.Drawing.Point(524, 190);
            this.pricebraisedlamb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricebraisedlamb.Name = "pricebraisedlamb";
            this.pricebraisedlamb.Size = new System.Drawing.Size(93, 39);
            this.pricebraisedlamb.TabIndex = 3;
            this.pricebraisedlamb.Text = "1700";
            // 
            // qtypaneerkofta
            // 
            this.qtypaneerkofta.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtypaneerkofta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtypaneerkofta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtypaneerkofta.Enabled = false;
            this.qtypaneerkofta.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtypaneerkofta.ForeColor = System.Drawing.Color.White;
            this.qtypaneerkofta.Location = new System.Drawing.Point(411, 71);
            this.qtypaneerkofta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtypaneerkofta.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtypaneerkofta.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtypaneerkofta.Name = "qtypaneerkofta";
            this.qtypaneerkofta.Size = new System.Drawing.Size(61, 36);
            this.qtypaneerkofta.TabIndex = 9;
            this.qtypaneerkofta.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtypaneerkofta.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtypaneerkofta.ValueChanged += new System.EventHandler(this.qtypaneerkofta_ValueChanged);
            // 
            // pricericottavada
            // 
            this.pricericottavada.AutoSize = true;
            this.pricericottavada.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricericottavada.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricericottavada.ForeColor = System.Drawing.Color.White;
            this.pricericottavada.Location = new System.Drawing.Point(544, 130);
            this.pricericottavada.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricericottavada.Name = "pricericottavada";
            this.pricericottavada.Size = new System.Drawing.Size(74, 39);
            this.pricericottavada.TabIndex = 3;
            this.pricericottavada.Text = "900";
            // 
            // pricepaneerkofta
            // 
            this.pricepaneerkofta.AutoSize = true;
            this.pricepaneerkofta.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricepaneerkofta.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricepaneerkofta.ForeColor = System.Drawing.Color.White;
            this.pricepaneerkofta.Location = new System.Drawing.Point(524, 71);
            this.pricepaneerkofta.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricepaneerkofta.Name = "pricepaneerkofta";
            this.pricepaneerkofta.Size = new System.Drawing.Size(93, 39);
            this.pricepaneerkofta.TabIndex = 3;
            this.pricepaneerkofta.Text = "1050";
            // 
            // chkpulledporksteak
            // 
            this.chkpulledporksteak.AutoSize = true;
            this.chkpulledporksteak.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkpulledporksteak.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkpulledporksteak.ForeColor = System.Drawing.Color.White;
            this.chkpulledporksteak.Location = new System.Drawing.Point(8, 304);
            this.chkpulledporksteak.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkpulledporksteak.Name = "chkpulledporksteak";
            this.chkpulledporksteak.Size = new System.Drawing.Size(315, 44);
            this.chkpulledporksteak.TabIndex = 1;
            this.chkpulledporksteak.Text = "Pulled Pork Steak";
            this.chkpulledporksteak.UseVisualStyleBackColor = true;
            this.chkpulledporksteak.CheckedChanged += new System.EventHandler(this.chkpulledporksteak_CheckedChanged);
            // 
            // chkbakedseabass
            // 
            this.chkbakedseabass.AutoSize = true;
            this.chkbakedseabass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkbakedseabass.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbakedseabass.ForeColor = System.Drawing.Color.White;
            this.chkbakedseabass.Location = new System.Drawing.Point(8, 245);
            this.chkbakedseabass.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkbakedseabass.Name = "chkbakedseabass";
            this.chkbakedseabass.Size = new System.Drawing.Size(320, 44);
            this.chkbakedseabass.TabIndex = 1;
            this.chkbakedseabass.Text = "Baked Sea Bass   ";
            this.chkbakedseabass.UseVisualStyleBackColor = true;
            this.chkbakedseabass.CheckedChanged += new System.EventHandler(this.chkbakedseabass_CheckedChanged);
            // 
            // chkbraisedlamb
            // 
            this.chkbraisedlamb.AutoSize = true;
            this.chkbraisedlamb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkbraisedlamb.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkbraisedlamb.ForeColor = System.Drawing.Color.White;
            this.chkbraisedlamb.Location = new System.Drawing.Point(8, 186);
            this.chkbraisedlamb.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkbraisedlamb.Name = "chkbraisedlamb";
            this.chkbraisedlamb.Size = new System.Drawing.Size(303, 44);
            this.chkbraisedlamb.TabIndex = 1;
            this.chkbraisedlamb.Text = "Braised Lamb     ";
            this.chkbraisedlamb.UseVisualStyleBackColor = true;
            this.chkbraisedlamb.CheckedChanged += new System.EventHandler(this.chkbraisedlamb_CheckedChanged);
            // 
            // chkricottavada
            // 
            this.chkricottavada.AutoSize = true;
            this.chkricottavada.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkricottavada.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkricottavada.ForeColor = System.Drawing.Color.White;
            this.chkricottavada.Location = new System.Drawing.Point(8, 127);
            this.chkricottavada.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkricottavada.Name = "chkricottavada";
            this.chkricottavada.Size = new System.Drawing.Size(304, 44);
            this.chkricottavada.TabIndex = 1;
            this.chkricottavada.Text = "Ricotta Vada     ";
            this.chkricottavada.UseVisualStyleBackColor = true;
            this.chkricottavada.CheckedChanged += new System.EventHandler(this.chkricottavada_CheckedChanged);
            // 
            // chkpaneerkofta
            // 
            this.chkpaneerkofta.AutoSize = true;
            this.chkpaneerkofta.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkpaneerkofta.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkpaneerkofta.ForeColor = System.Drawing.Color.White;
            this.chkpaneerkofta.Location = new System.Drawing.Point(8, 68);
            this.chkpaneerkofta.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkpaneerkofta.Name = "chkpaneerkofta";
            this.chkpaneerkofta.Size = new System.Drawing.Size(299, 44);
            this.chkpaneerkofta.TabIndex = 1;
            this.chkpaneerkofta.Text = "Paneer Kofta     ";
            this.chkpaneerkofta.UseVisualStyleBackColor = true;
            this.chkpaneerkofta.CheckedChanged += new System.EventHandler(this.chkpaneerkofta_CheckedChanged);
            // 
            // mainsqty
            // 
            this.mainsqty.AutoSize = true;
            this.mainsqty.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainsqty.ForeColor = System.Drawing.Color.White;
            this.mainsqty.Location = new System.Drawing.Point(401, 0);
            this.mainsqty.Margin = new System.Windows.Forms.Padding(0);
            this.mainsqty.Name = "mainsqty";
            this.mainsqty.Size = new System.Drawing.Size(91, 50);
            this.mainsqty.TabIndex = 0;
            this.mainsqty.Text = "Qty";
            // 
            // mainsprice
            // 
            this.mainsprice.AutoSize = true;
            this.mainsprice.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mainsprice.ForeColor = System.Drawing.Color.White;
            this.mainsprice.Location = new System.Drawing.Point(517, 0);
            this.mainsprice.Margin = new System.Windows.Forms.Padding(0);
            this.mainsprice.Name = "mainsprice";
            this.mainsprice.Size = new System.Drawing.Size(119, 50);
            this.mainsprice.TabIndex = 0;
            this.mainsprice.Text = "Price";
            // 
            // mains
            // 
            this.mains.AutoSize = true;
            this.mains.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mains.ForeColor = System.Drawing.Color.White;
            this.mains.Location = new System.Drawing.Point(-1, 0);
            this.mains.Margin = new System.Windows.Forms.Padding(0);
            this.mains.Name = "mains";
            this.mains.Size = new System.Drawing.Size(150, 50);
            this.mains.TabIndex = 0;
            this.mains.Text = "MAINS";
            // 
            // appetizerspanel
            // 
            this.appetizerspanel.BackColor = System.Drawing.Color.Teal;
            this.appetizerspanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.appetizerspanel.Controls.Add(this.qtysemolinapuchkas);
            this.appetizerspanel.Controls.Add(this.qtymorelmusallam);
            this.appetizerspanel.Controls.Add(this.qtysmokedduck);
            this.appetizerspanel.Controls.Add(this.qtyroastmuttonboti);
            this.appetizerspanel.Controls.Add(this.chksemolinapuchkas);
            this.appetizerspanel.Controls.Add(this.qtypulledporktaco);
            this.appetizerspanel.Controls.Add(this.pricesemolinapuchkas);
            this.appetizerspanel.Controls.Add(this.pricemorelmusallam);
            this.appetizerspanel.Controls.Add(this.pricesmokedduck);
            this.appetizerspanel.Controls.Add(this.priceroastmuttonboti);
            this.appetizerspanel.Controls.Add(this.pricepulledporktaco);
            this.appetizerspanel.Controls.Add(this.chkmorelmusallam);
            this.appetizerspanel.Controls.Add(this.chksmokedduck);
            this.appetizerspanel.Controls.Add(this.chkroastmuttonboti);
            this.appetizerspanel.Controls.Add(this.chkpulledporktaco);
            this.appetizerspanel.Controls.Add(this.appetizersqty);
            this.appetizerspanel.Controls.Add(this.appetizersprice);
            this.appetizerspanel.Controls.Add(this.appetizers);
            this.appetizerspanel.Location = new System.Drawing.Point(13, 12);
            this.appetizerspanel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.appetizerspanel.Name = "appetizerspanel";
            this.appetizerspanel.Size = new System.Drawing.Size(645, 368);
            this.appetizerspanel.TabIndex = 0;
            // 
            // qtysemolinapuchkas
            // 
            this.qtysemolinapuchkas.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtysemolinapuchkas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtysemolinapuchkas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtysemolinapuchkas.Enabled = false;
            this.qtysemolinapuchkas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtysemolinapuchkas.ForeColor = System.Drawing.Color.White;
            this.qtysemolinapuchkas.Location = new System.Drawing.Point(411, 76);
            this.qtysemolinapuchkas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtysemolinapuchkas.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtysemolinapuchkas.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtysemolinapuchkas.Name = "qtysemolinapuchkas";
            this.qtysemolinapuchkas.Size = new System.Drawing.Size(61, 36);
            this.qtysemolinapuchkas.TabIndex = 4;
            this.qtysemolinapuchkas.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtysemolinapuchkas.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtysemolinapuchkas.ValueChanged += new System.EventHandler(this.qtysemolinapuchkas_ValueChanged);
            // 
            // qtymorelmusallam
            // 
            this.qtymorelmusallam.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtymorelmusallam.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtymorelmusallam.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtymorelmusallam.Enabled = false;
            this.qtymorelmusallam.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtymorelmusallam.ForeColor = System.Drawing.Color.White;
            this.qtymorelmusallam.Location = new System.Drawing.Point(411, 135);
            this.qtymorelmusallam.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtymorelmusallam.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtymorelmusallam.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymorelmusallam.Name = "qtymorelmusallam";
            this.qtymorelmusallam.Size = new System.Drawing.Size(61, 36);
            this.qtymorelmusallam.TabIndex = 4;
            this.qtymorelmusallam.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtymorelmusallam.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtymorelmusallam.ValueChanged += new System.EventHandler(this.qtymorelmusallam_ValueChanged);
            // 
            // qtysmokedduck
            // 
            this.qtysmokedduck.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtysmokedduck.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtysmokedduck.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtysmokedduck.Enabled = false;
            this.qtysmokedduck.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtysmokedduck.ForeColor = System.Drawing.Color.White;
            this.qtysmokedduck.Location = new System.Drawing.Point(411, 254);
            this.qtysmokedduck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtysmokedduck.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtysmokedduck.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtysmokedduck.Name = "qtysmokedduck";
            this.qtysmokedduck.Size = new System.Drawing.Size(61, 36);
            this.qtysmokedduck.TabIndex = 4;
            this.qtysmokedduck.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtysmokedduck.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtysmokedduck.ValueChanged += new System.EventHandler(this.qtysmokedduck_ValueChanged);
            // 
            // qtyroastmuttonboti
            // 
            this.qtyroastmuttonboti.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtyroastmuttonboti.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtyroastmuttonboti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtyroastmuttonboti.Enabled = false;
            this.qtyroastmuttonboti.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtyroastmuttonboti.ForeColor = System.Drawing.Color.White;
            this.qtyroastmuttonboti.Location = new System.Drawing.Point(411, 194);
            this.qtyroastmuttonboti.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtyroastmuttonboti.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtyroastmuttonboti.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtyroastmuttonboti.Name = "qtyroastmuttonboti";
            this.qtyroastmuttonboti.Size = new System.Drawing.Size(61, 36);
            this.qtyroastmuttonboti.TabIndex = 4;
            this.qtyroastmuttonboti.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtyroastmuttonboti.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtyroastmuttonboti.ValueChanged += new System.EventHandler(this.qtyroastmuttonboti_ValueChanged);
            // 
            // chksemolinapuchkas
            // 
            this.chksemolinapuchkas.AutoSize = true;
            this.chksemolinapuchkas.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chksemolinapuchkas.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chksemolinapuchkas.ForeColor = System.Drawing.Color.White;
            this.chksemolinapuchkas.Location = new System.Drawing.Point(8, 73);
            this.chksemolinapuchkas.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chksemolinapuchkas.Name = "chksemolinapuchkas";
            this.chksemolinapuchkas.Size = new System.Drawing.Size(342, 44);
            this.chksemolinapuchkas.TabIndex = 1;
            this.chksemolinapuchkas.Text = "Semolina Puchkas ";
            this.chksemolinapuchkas.UseVisualStyleBackColor = true;
            this.chksemolinapuchkas.CheckedChanged += new System.EventHandler(this.chksemolinapuchkas_CheckedChanged);
            // 
            // qtypulledporktaco
            // 
            this.qtypulledporktaco.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.qtypulledporktaco.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.qtypulledporktaco.Cursor = System.Windows.Forms.Cursors.Hand;
            this.qtypulledporktaco.Enabled = false;
            this.qtypulledporktaco.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qtypulledporktaco.ForeColor = System.Drawing.Color.White;
            this.qtypulledporktaco.Location = new System.Drawing.Point(411, 313);
            this.qtypulledporktaco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.qtypulledporktaco.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.qtypulledporktaco.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtypulledporktaco.Name = "qtypulledporktaco";
            this.qtypulledporktaco.Size = new System.Drawing.Size(61, 36);
            this.qtypulledporktaco.TabIndex = 4;
            this.qtypulledporktaco.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.qtypulledporktaco.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.qtypulledporktaco.ValueChanged += new System.EventHandler(this.qtypulledporktaco_ValueChanged);
            // 
            // pricesemolinapuchkas
            // 
            this.pricesemolinapuchkas.AutoSize = true;
            this.pricesemolinapuchkas.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricesemolinapuchkas.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricesemolinapuchkas.ForeColor = System.Drawing.Color.White;
            this.pricesemolinapuchkas.Location = new System.Drawing.Point(544, 71);
            this.pricesemolinapuchkas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricesemolinapuchkas.Name = "pricesemolinapuchkas";
            this.pricesemolinapuchkas.Size = new System.Drawing.Size(74, 39);
            this.pricesemolinapuchkas.TabIndex = 3;
            this.pricesemolinapuchkas.Text = "650";
            // 
            // pricemorelmusallam
            // 
            this.pricemorelmusallam.AutoSize = true;
            this.pricemorelmusallam.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricemorelmusallam.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricemorelmusallam.ForeColor = System.Drawing.Color.White;
            this.pricemorelmusallam.Location = new System.Drawing.Point(524, 132);
            this.pricemorelmusallam.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricemorelmusallam.Name = "pricemorelmusallam";
            this.pricemorelmusallam.Size = new System.Drawing.Size(93, 39);
            this.pricemorelmusallam.TabIndex = 3;
            this.pricemorelmusallam.Text = "1400";
            // 
            // pricesmokedduck
            // 
            this.pricesmokedduck.AutoSize = true;
            this.pricesmokedduck.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricesmokedduck.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricesmokedduck.ForeColor = System.Drawing.Color.White;
            this.pricesmokedduck.Location = new System.Drawing.Point(524, 252);
            this.pricesmokedduck.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricesmokedduck.Name = "pricesmokedduck";
            this.pricesmokedduck.Size = new System.Drawing.Size(93, 39);
            this.pricesmokedduck.TabIndex = 3;
            this.pricesmokedduck.Text = "1450";
            // 
            // priceroastmuttonboti
            // 
            this.priceroastmuttonboti.AutoSize = true;
            this.priceroastmuttonboti.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.priceroastmuttonboti.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.priceroastmuttonboti.ForeColor = System.Drawing.Color.White;
            this.priceroastmuttonboti.Location = new System.Drawing.Point(524, 192);
            this.priceroastmuttonboti.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.priceroastmuttonboti.Name = "priceroastmuttonboti";
            this.priceroastmuttonboti.Size = new System.Drawing.Size(93, 39);
            this.priceroastmuttonboti.TabIndex = 3;
            this.priceroastmuttonboti.Text = "1900";
            // 
            // pricepulledporktaco
            // 
            this.pricepulledporktaco.AutoSize = true;
            this.pricepulledporktaco.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.pricepulledporktaco.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pricepulledporktaco.ForeColor = System.Drawing.Color.White;
            this.pricepulledporktaco.Location = new System.Drawing.Point(524, 313);
            this.pricepulledporktaco.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pricepulledporktaco.Name = "pricepulledporktaco";
            this.pricepulledporktaco.Size = new System.Drawing.Size(93, 39);
            this.pricepulledporktaco.TabIndex = 3;
            this.pricepulledporktaco.Text = "1100";
            // 
            // chkmorelmusallam
            // 
            this.chkmorelmusallam.AutoSize = true;
            this.chkmorelmusallam.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkmorelmusallam.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkmorelmusallam.ForeColor = System.Drawing.Color.White;
            this.chkmorelmusallam.Location = new System.Drawing.Point(8, 132);
            this.chkmorelmusallam.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkmorelmusallam.Name = "chkmorelmusallam";
            this.chkmorelmusallam.Size = new System.Drawing.Size(319, 44);
            this.chkmorelmusallam.TabIndex = 1;
            this.chkmorelmusallam.Text = "Morel Musallam   ";
            this.chkmorelmusallam.UseVisualStyleBackColor = true;
            this.chkmorelmusallam.CheckedChanged += new System.EventHandler(this.chkmorelmusallam_CheckedChanged);
            // 
            // chksmokedduck
            // 
            this.chksmokedduck.AutoSize = true;
            this.chksmokedduck.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chksmokedduck.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chksmokedduck.ForeColor = System.Drawing.Color.White;
            this.chksmokedduck.Location = new System.Drawing.Point(8, 250);
            this.chksmokedduck.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chksmokedduck.Name = "chksmokedduck";
            this.chksmokedduck.Size = new System.Drawing.Size(318, 44);
            this.chksmokedduck.TabIndex = 1;
            this.chksmokedduck.Text = "Smoked Duck      ";
            this.chksmokedduck.UseVisualStyleBackColor = true;
            this.chksmokedduck.CheckedChanged += new System.EventHandler(this.chksmokedduck_CheckedChanged);
            // 
            // chkroastmuttonboti
            // 
            this.chkroastmuttonboti.AutoSize = true;
            this.chkroastmuttonboti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkroastmuttonboti.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkroastmuttonboti.ForeColor = System.Drawing.Color.White;
            this.chkroastmuttonboti.Location = new System.Drawing.Point(8, 191);
            this.chkroastmuttonboti.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkroastmuttonboti.Name = "chkroastmuttonboti";
            this.chkroastmuttonboti.Size = new System.Drawing.Size(328, 44);
            this.chkroastmuttonboti.TabIndex = 1;
            this.chkroastmuttonboti.Text = "Roast Mutton Boti";
            this.chkroastmuttonboti.UseVisualStyleBackColor = true;
            this.chkroastmuttonboti.CheckedChanged += new System.EventHandler(this.chkroastmuttonboti_CheckedChanged);
            // 
            // chkpulledporktaco
            // 
            this.chkpulledporktaco.AutoSize = true;
            this.chkpulledporktaco.Cursor = System.Windows.Forms.Cursors.Hand;
            this.chkpulledporktaco.Font = new System.Drawing.Font("Century Gothic", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkpulledporktaco.ForeColor = System.Drawing.Color.White;
            this.chkpulledporktaco.Location = new System.Drawing.Point(8, 309);
            this.chkpulledporktaco.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkpulledporktaco.Name = "chkpulledporktaco";
            this.chkpulledporktaco.Size = new System.Drawing.Size(313, 44);
            this.chkpulledporktaco.TabIndex = 1;
            this.chkpulledporktaco.Text = "Pulled Pork Taco ";
            this.chkpulledporktaco.UseVisualStyleBackColor = true;
            this.chkpulledporktaco.CheckedChanged += new System.EventHandler(this.chkpulledporktaco_CheckedChanged);
            // 
            // appetizersqty
            // 
            this.appetizersqty.AutoSize = true;
            this.appetizersqty.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appetizersqty.ForeColor = System.Drawing.Color.White;
            this.appetizersqty.Location = new System.Drawing.Point(401, 0);
            this.appetizersqty.Margin = new System.Windows.Forms.Padding(0);
            this.appetizersqty.Name = "appetizersqty";
            this.appetizersqty.Size = new System.Drawing.Size(91, 50);
            this.appetizersqty.TabIndex = 0;
            this.appetizersqty.Text = "Qty";
            // 
            // appetizersprice
            // 
            this.appetizersprice.AutoSize = true;
            this.appetizersprice.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appetizersprice.ForeColor = System.Drawing.Color.White;
            this.appetizersprice.Location = new System.Drawing.Point(517, 0);
            this.appetizersprice.Margin = new System.Windows.Forms.Padding(0);
            this.appetizersprice.Name = "appetizersprice";
            this.appetizersprice.Size = new System.Drawing.Size(119, 50);
            this.appetizersprice.TabIndex = 0;
            this.appetizersprice.Text = "Price";
            // 
            // appetizers
            // 
            this.appetizers.AutoSize = true;
            this.appetizers.Font = new System.Drawing.Font("Century Gothic", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appetizers.ForeColor = System.Drawing.Color.White;
            this.appetizers.Location = new System.Drawing.Point(-1, 0);
            this.appetizers.Margin = new System.Windows.Forms.Padding(0);
            this.appetizers.Name = "appetizers";
            this.appetizers.Size = new System.Drawing.Size(230, 50);
            this.appetizers.TabIndex = 0;
            this.appetizers.Text = "APPETIZERS";
            // 
            // menuform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1813, 970);
            this.Controls.Add(this.mcentrepanel);
            this.Controls.Add(this.cartpanel);
            this.Controls.Add(this.mtoppanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "menuform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "menuform";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.cartpanel.ResumeLayout(false);
            this.cartpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.datagridviewcart)).EndInit();
            this.mtoppanel.ResumeLayout(false);
            this.mtoppanel.PerformLayout();
            this.mcentrepanel.ResumeLayout(false);
            this.mcentrepanel.PerformLayout();
            this.beveragespanel.ResumeLayout(false);
            this.beveragespanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtydarjeelingtea)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymanhattan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymallowginger)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtyespresso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtybombaysapphire)).EndInit();
            this.snackspanel.ResumeLayout(false);
            this.snackspanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtyfrenchbbqfries)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymexicandream)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtycarbonara)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtygcsandwich)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymcburger)).EndInit();
            this.mainspanel.ResumeLayout(false);
            this.mainspanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtybakedseabass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtypulledporksteak)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtybraisedlamb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtyricottavada)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtypaneerkofta)).EndInit();
            this.appetizerspanel.ResumeLayout(false);
            this.appetizerspanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.qtysemolinapuchkas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtymorelmusallam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtysmokedduck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtyroastmuttonboti)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.qtypulledporktaco)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel cartpanel;
        private System.Windows.Forms.Panel mtoppanel;
        private System.Windows.Forms.Panel mcentrepanel;
        private System.Windows.Forms.Panel beveragespanel;
        private System.Windows.Forms.Label pricemanhattan;
        private System.Windows.Forms.Label pricedarjeelingtea;
        private System.Windows.Forms.Label pricemallowginger;
        private System.Windows.Forms.Label priceespresso;
        private System.Windows.Forms.Label pricebombaysapphire;
        private System.Windows.Forms.CheckBox chkmanhattan;
        private System.Windows.Forms.CheckBox chkdarjeelingtea;
        private System.Windows.Forms.CheckBox chkmallowginger;
        private System.Windows.Forms.CheckBox chkespresso;
        private System.Windows.Forms.CheckBox chkbombaysapphire;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Panel snackspanel;
        private System.Windows.Forms.Label pricemexicandream;
        private System.Windows.Forms.Label pricefrenchbbqfries;
        private System.Windows.Forms.Label pricecarbonara;
        private System.Windows.Forms.Label pricegcsandwich;
        private System.Windows.Forms.Label pricemcburger;
        private System.Windows.Forms.CheckBox chkmexicandream;
        private System.Windows.Forms.CheckBox chkfrenchbbqfries;
        private System.Windows.Forms.CheckBox chkcarbonara;
        private System.Windows.Forms.CheckBox chkgcsandwich;
        private System.Windows.Forms.CheckBox chkmcburger;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel mainspanel;
        private System.Windows.Forms.Label pricepulledporksteak;
        private System.Windows.Forms.Label pricebakedseabass;
        private System.Windows.Forms.Label pricebraisedlamb;
        private System.Windows.Forms.Label pricericottavada;
        private System.Windows.Forms.Label pricepaneerkofta;
        private System.Windows.Forms.CheckBox chkpulledporksteak;
        private System.Windows.Forms.CheckBox chkbakedseabass;
        private System.Windows.Forms.CheckBox chkbraisedlamb;
        private System.Windows.Forms.CheckBox chkricottavada;
        private System.Windows.Forms.CheckBox chkpaneerkofta;
        private System.Windows.Forms.Label mainsqty;
        private System.Windows.Forms.Label mainsprice;
        private System.Windows.Forms.Label mains;
        private System.Windows.Forms.Panel appetizerspanel;
        private System.Windows.Forms.Label pricemorelmusallam;
        private System.Windows.Forms.Label pricesemolinapuchkas;
        private System.Windows.Forms.Label pricesmokedduck;
        private System.Windows.Forms.Label priceroastmuttonboti;
        private System.Windows.Forms.Label pricepulledporktaco;
        private System.Windows.Forms.CheckBox chkmorelmusallam;
        private System.Windows.Forms.CheckBox chksemolinapuchkas;
        private System.Windows.Forms.CheckBox chksmokedduck;
        private System.Windows.Forms.CheckBox chkroastmuttonboti;
        private System.Windows.Forms.CheckBox chkpulledporktaco;
        private System.Windows.Forms.Label appetizersqty;
        private System.Windows.Forms.Label appetizersprice;
        private System.Windows.Forms.Label appetizers;
        private System.Windows.Forms.Label mEasyDine;
        private System.Windows.Forms.Label mmycart;
        private System.Windows.Forms.Label mmenu;
        private System.Windows.Forms.Button mresetbtn;
        private System.Windows.Forms.Button mgeneratereceiptbtn;
        private System.Windows.Forms.Button mclosebtn;
        private System.Windows.Forms.NumericUpDown qtydarjeelingtea;
        private System.Windows.Forms.NumericUpDown qtymanhattan;
        private System.Windows.Forms.NumericUpDown qtymallowginger;
        private System.Windows.Forms.NumericUpDown qtyespresso;
        private System.Windows.Forms.NumericUpDown qtybombaysapphire;
        private System.Windows.Forms.NumericUpDown qtyfrenchbbqfries;
        private System.Windows.Forms.NumericUpDown qtymexicandream;
        private System.Windows.Forms.NumericUpDown qtycarbonara;
        private System.Windows.Forms.NumericUpDown qtygcsandwich;
        private System.Windows.Forms.NumericUpDown qtymcburger;
        private System.Windows.Forms.NumericUpDown qtybakedseabass;
        private System.Windows.Forms.NumericUpDown qtypulledporksteak;
        private System.Windows.Forms.NumericUpDown qtybraisedlamb;
        private System.Windows.Forms.NumericUpDown qtyricottavada;
        private System.Windows.Forms.NumericUpDown qtypaneerkofta;
        private System.Windows.Forms.NumericUpDown qtysemolinapuchkas;
        private System.Windows.Forms.NumericUpDown qtymorelmusallam;
        private System.Windows.Forms.NumericUpDown qtysmokedduck;
        private System.Windows.Forms.NumericUpDown qtyroastmuttonboti;
        private System.Windows.Forms.NumericUpDown qtypulledporktaco;
        private System.Windows.Forms.Label billamount;
        private System.Windows.Forms.Label carttax;
        private System.Windows.Forms.Label carttotal;
        private System.Windows.Forms.TextBox billamountbox;
        private System.Windows.Forms.TextBox taxbox;
        private System.Windows.Forms.TextBox carttotalbox;
        private System.Windows.Forms.Button mcalculatebtn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.CheckBox chkveg;
        public System.Windows.Forms.DataGridView datagridviewcart;
    }
}