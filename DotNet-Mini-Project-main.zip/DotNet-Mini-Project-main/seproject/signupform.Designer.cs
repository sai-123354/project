﻿namespace seproject
{
    partial class signupform
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sleftpanel = new System.Windows.Forms.Panel();
            this.sdevelopername = new System.Windows.Forms.Label();
            this.sdevelopedby = new System.Windows.Forms.Label();
            this.screatenewacc1 = new System.Windows.Forms.Label();
            this.slogintoyouraccount1 = new System.Windows.Forms.Label();
            this.sEasyDine = new System.Windows.Forms.Label();
            this.srightpanel = new System.Windows.Forms.Panel();
            this.ssignupbtn = new System.Windows.Forms.Button();
            this.sloginbtn = new System.Windows.Forms.Button();
            this.sclydenmail = new System.Windows.Forms.LinkLabel();
            this.screatenewacc2 = new System.Windows.Forms.Label();
            this.saafilmail = new System.Windows.Forms.LinkLabel();
            this.sclosebtn = new System.Windows.Forms.Button();
            this.ssupport3 = new System.Windows.Forms.Label();
            this.ssupport2 = new System.Windows.Forms.Label();
            this.ssupport1 = new System.Windows.Forms.Label();
            this.confirmpasswordarea = new System.Windows.Forms.Panel();
            this.passwordshowbtn2 = new System.Windows.Forms.Button();
            this.confirmpasswordbox = new System.Windows.Forms.TextBox();
            this.confirmpassword = new System.Windows.Forms.Label();
            this.createpasswordarea = new System.Windows.Forms.Panel();
            this.passwordshowbtn1 = new System.Windows.Forms.Button();
            this.createpasswordbox = new System.Windows.Forms.TextBox();
            this.createpassword = new System.Windows.Forms.Label();
            this.emailarea = new System.Windows.Forms.Panel();
            this.emailbox = new System.Windows.Forms.TextBox();
            this.email = new System.Windows.Forms.Label();
            this.namearea = new System.Windows.Forms.Panel();
            this.namebox = new System.Windows.Forms.TextBox();
            this.name = new System.Windows.Forms.Label();
            this.createusernamearea = new System.Windows.Forms.Panel();
            this.creatusernamebox = new System.Windows.Forms.TextBox();
            this.createusername = new System.Windows.Forms.Label();
            this.sleftpanel.SuspendLayout();
            this.srightpanel.SuspendLayout();
            this.confirmpasswordarea.SuspendLayout();
            this.createpasswordarea.SuspendLayout();
            this.emailarea.SuspendLayout();
            this.namearea.SuspendLayout();
            this.createusernamearea.SuspendLayout();
            this.SuspendLayout();
            // 
            // sleftpanel
            // 
            this.sleftpanel.BackColor = System.Drawing.Color.Teal;
            this.sleftpanel.Controls.Add(this.sdevelopername);
            this.sleftpanel.Controls.Add(this.sdevelopedby);
            this.sleftpanel.Controls.Add(this.screatenewacc1);
            this.sleftpanel.Controls.Add(this.slogintoyouraccount1);
            this.sleftpanel.Controls.Add(this.sEasyDine);
            this.sleftpanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sleftpanel.Location = new System.Drawing.Point(0, 0);
            this.sleftpanel.Margin = new System.Windows.Forms.Padding(4);
            this.sleftpanel.Name = "sleftpanel";
            this.sleftpanel.Size = new System.Drawing.Size(400, 615);
            this.sleftpanel.TabIndex = 1;
            // 
            // sdevelopername
            // 
            this.sdevelopername.AutoSize = true;
            this.sdevelopername.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sdevelopername.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sdevelopername.ForeColor = System.Drawing.SystemColors.Control;
            this.sdevelopername.Location = new System.Drawing.Point(96, 556);
            this.sdevelopername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sdevelopername.Name = "sdevelopername";
            this.sdevelopername.Size = new System.Drawing.Size(263, 21);
            this.sdevelopername.TabIndex = 0;
            this.sdevelopername.Text = "Aafil Shaikh | Clyden Pacheco";
            // 
            // sdevelopedby
            // 
            this.sdevelopedby.AutoSize = true;
            this.sdevelopedby.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sdevelopedby.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sdevelopedby.ForeColor = System.Drawing.SystemColors.Control;
            this.sdevelopedby.Location = new System.Drawing.Point(249, 533);
            this.sdevelopedby.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sdevelopedby.Name = "sdevelopedby";
            this.sdevelopedby.Size = new System.Drawing.Size(128, 21);
            this.sdevelopedby.TabIndex = 0;
            this.sdevelopedby.Text = "Developed By";
            // 
            // screatenewacc1
            // 
            this.screatenewacc1.AutoSize = true;
            this.screatenewacc1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.screatenewacc1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.screatenewacc1.ForeColor = System.Drawing.SystemColors.Control;
            this.screatenewacc1.Location = new System.Drawing.Point(11, 283);
            this.screatenewacc1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.screatenewacc1.Name = "screatenewacc1";
            this.screatenewacc1.Size = new System.Drawing.Size(349, 37);
            this.screatenewacc1.TabIndex = 0;
            this.screatenewacc1.Text = "Create a new account";
            // 
            // slogintoyouraccount1
            // 
            this.slogintoyouraccount1.AutoSize = true;
            this.slogintoyouraccount1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.slogintoyouraccount1.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.slogintoyouraccount1.ForeColor = System.Drawing.SystemColors.Control;
            this.slogintoyouraccount1.Location = new System.Drawing.Point(25, 239);
            this.slogintoyouraccount1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.slogintoyouraccount1.Name = "slogintoyouraccount1";
            this.slogintoyouraccount1.Size = new System.Drawing.Size(339, 37);
            this.slogintoyouraccount1.TabIndex = 0;
            this.slogintoyouraccount1.Text = "Login to your account";
            // 
            // sEasyDine
            // 
            this.sEasyDine.AutoSize = true;
            this.sEasyDine.Font = new System.Drawing.Font("Century Gothic", 30F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sEasyDine.ForeColor = System.Drawing.SystemColors.Control;
            this.sEasyDine.Location = new System.Drawing.Point(131, 150);
            this.sEasyDine.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sEasyDine.Name = "sEasyDine";
            this.sEasyDine.Size = new System.Drawing.Size(244, 60);
            this.sEasyDine.TabIndex = 0;
            this.sEasyDine.Text = "EasyDine";
            // 
            // srightpanel
            // 
            this.srightpanel.BackColor = System.Drawing.Color.Gainsboro;
            this.srightpanel.Controls.Add(this.ssignupbtn);
            this.srightpanel.Controls.Add(this.sloginbtn);
            this.srightpanel.Controls.Add(this.sclydenmail);
            this.srightpanel.Controls.Add(this.screatenewacc2);
            this.srightpanel.Controls.Add(this.saafilmail);
            this.srightpanel.Controls.Add(this.sclosebtn);
            this.srightpanel.Controls.Add(this.ssupport3);
            this.srightpanel.Controls.Add(this.ssupport2);
            this.srightpanel.Controls.Add(this.ssupport1);
            this.srightpanel.Controls.Add(this.confirmpasswordarea);
            this.srightpanel.Controls.Add(this.createpasswordarea);
            this.srightpanel.Controls.Add(this.emailarea);
            this.srightpanel.Controls.Add(this.namearea);
            this.srightpanel.Controls.Add(this.createusernamearea);
            this.srightpanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.srightpanel.Location = new System.Drawing.Point(400, 0);
            this.srightpanel.Margin = new System.Windows.Forms.Padding(4);
            this.srightpanel.Name = "srightpanel";
            this.srightpanel.Size = new System.Drawing.Size(773, 615);
            this.srightpanel.TabIndex = 2;
            // 
            // ssignupbtn
            // 
            this.ssignupbtn.BackColor = System.Drawing.Color.Silver;
            this.ssignupbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.ssignupbtn.FlatAppearance.BorderSize = 0;
            this.ssignupbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ssignupbtn.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssignupbtn.ForeColor = System.Drawing.Color.Teal;
            this.ssignupbtn.Location = new System.Drawing.Point(375, 447);
            this.ssignupbtn.Margin = new System.Windows.Forms.Padding(4);
            this.ssignupbtn.Name = "ssignupbtn";
            this.ssignupbtn.Size = new System.Drawing.Size(227, 49);
            this.ssignupbtn.TabIndex = 4;
            this.ssignupbtn.Text = "LOGIN";
            this.ssignupbtn.UseVisualStyleBackColor = false;
            this.ssignupbtn.Click += new System.EventHandler(this.ssignupbtn_Click);
            // 
            // sloginbtn
            // 
            this.sloginbtn.BackColor = System.Drawing.Color.Teal;
            this.sloginbtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sloginbtn.FlatAppearance.BorderSize = 0;
            this.sloginbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sloginbtn.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sloginbtn.ForeColor = System.Drawing.SystemColors.Control;
            this.sloginbtn.Location = new System.Drawing.Point(124, 447);
            this.sloginbtn.Margin = new System.Windows.Forms.Padding(4);
            this.sloginbtn.Name = "sloginbtn";
            this.sloginbtn.Size = new System.Drawing.Size(227, 49);
            this.sloginbtn.TabIndex = 4;
            this.sloginbtn.Text = "SIGN UP";
            this.sloginbtn.UseVisualStyleBackColor = false;
            this.sloginbtn.Click += new System.EventHandler(this.sloginbtn_Click);
            // 
            // sclydenmail
            // 
            this.sclydenmail.AutoSize = true;
            this.sclydenmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sclydenmail.LinkColor = System.Drawing.Color.Teal;
            this.sclydenmail.Location = new System.Drawing.Point(463, 583);
            this.sclydenmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sclydenmail.Name = "sclydenmail";
            this.sclydenmail.Size = new System.Drawing.Size(176, 16);
            this.sclydenmail.TabIndex = 3;
            this.sclydenmail.TabStop = true;
            this.sclydenmail.Text = "clydenpacheco@gmail.com";
            // 
            // screatenewacc2
            // 
            this.screatenewacc2.AutoSize = true;
            this.screatenewacc2.BackColor = System.Drawing.Color.Transparent;
            this.screatenewacc2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.screatenewacc2.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.screatenewacc2.ForeColor = System.Drawing.Color.Teal;
            this.screatenewacc2.Location = new System.Drawing.Point(8, 38);
            this.screatenewacc2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.screatenewacc2.Name = "screatenewacc2";
            this.screatenewacc2.Size = new System.Drawing.Size(358, 37);
            this.screatenewacc2.TabIndex = 0;
            this.screatenewacc2.Text = "Create a new account:\r\n";
            // 
            // saafilmail
            // 
            this.saafilmail.AutoSize = true;
            this.saafilmail.Cursor = System.Windows.Forms.Cursors.Hand;
            this.saafilmail.LinkColor = System.Drawing.Color.Teal;
            this.saafilmail.Location = new System.Drawing.Point(269, 583);
            this.saafilmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.saafilmail.Name = "saafilmail";
            this.saafilmail.Size = new System.Drawing.Size(175, 16);
            this.saafilmail.TabIndex = 3;
            this.saafilmail.TabStop = true;
            this.saafilmail.Text = "aafilshaikh1043@gmail.com";
            // 
            // sclosebtn
            // 
            this.sclosebtn.BackColor = System.Drawing.Color.Transparent;
            this.sclosebtn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sclosebtn.FlatAppearance.BorderSize = 0;
            this.sclosebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sclosebtn.Font = new System.Drawing.Font("Verdana", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sclosebtn.ForeColor = System.Drawing.Color.Teal;
            this.sclosebtn.Location = new System.Drawing.Point(723, 0);
            this.sclosebtn.Margin = new System.Windows.Forms.Padding(4);
            this.sclosebtn.Name = "sclosebtn";
            this.sclosebtn.Size = new System.Drawing.Size(51, 47);
            this.sclosebtn.TabIndex = 2;
            this.sclosebtn.Text = "X";
            this.sclosebtn.UseVisualStyleBackColor = false;
            this.sclosebtn.Click += new System.EventHandler(this.sclosebtn_Click);
            this.sclosebtn.MouseEnter += new System.EventHandler(this.sclosebtn_MouseEnter);
            this.sclosebtn.MouseLeave += new System.EventHandler(this.sclosebtn_MouseLeave);
            // 
            // ssupport3
            // 
            this.ssupport3.AutoSize = true;
            this.ssupport3.BackColor = System.Drawing.Color.Transparent;
            this.ssupport3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ssupport3.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssupport3.ForeColor = System.Drawing.Color.DarkGray;
            this.ssupport3.Location = new System.Drawing.Point(9, 580);
            this.ssupport3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ssupport3.Name = "ssupport3";
            this.ssupport3.Size = new System.Drawing.Size(231, 21);
            this.ssupport3.TabIndex = 0;
            this.ssupport3.Text = "Mail and Connect with Us:";
            // 
            // ssupport2
            // 
            this.ssupport2.AutoSize = true;
            this.ssupport2.BackColor = System.Drawing.Color.Transparent;
            this.ssupport2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ssupport2.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssupport2.ForeColor = System.Drawing.Color.DarkGray;
            this.ssupport2.Location = new System.Drawing.Point(9, 556);
            this.ssupport2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ssupport2.Name = "ssupport2";
            this.ssupport2.Size = new System.Drawing.Size(347, 21);
            this.ssupport2.TabIndex = 0;
            this.ssupport2.Text = "Ask a query or access further information";
            // 
            // ssupport1
            // 
            this.ssupport1.AutoSize = true;
            this.ssupport1.BackColor = System.Drawing.Color.Transparent;
            this.ssupport1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ssupport1.Font = new System.Drawing.Font("Century Gothic", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssupport1.ForeColor = System.Drawing.Color.DarkGray;
            this.ssupport1.Location = new System.Drawing.Point(9, 533);
            this.ssupport1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ssupport1.Name = "ssupport1";
            this.ssupport1.Size = new System.Drawing.Size(80, 21);
            this.ssupport1.TabIndex = 0;
            this.ssupport1.Text = "Support:";
            // 
            // confirmpasswordarea
            // 
            this.confirmpasswordarea.BackColor = System.Drawing.Color.White;
            this.confirmpasswordarea.Controls.Add(this.passwordshowbtn2);
            this.confirmpasswordarea.Controls.Add(this.confirmpasswordbox);
            this.confirmpasswordarea.Controls.Add(this.confirmpassword);
            this.confirmpasswordarea.Location = new System.Drawing.Point(15, 361);
            this.confirmpasswordarea.Margin = new System.Windows.Forms.Padding(4);
            this.confirmpasswordarea.Name = "confirmpasswordarea";
            this.confirmpasswordarea.Size = new System.Drawing.Size(743, 37);
            this.confirmpasswordarea.TabIndex = 1;
            // 
            // passwordshowbtn2
            // 
            this.passwordshowbtn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.passwordshowbtn2.FlatAppearance.BorderSize = 0;
            this.passwordshowbtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.passwordshowbtn2.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordshowbtn2.ForeColor = System.Drawing.Color.Teal;
            this.passwordshowbtn2.Location = new System.Drawing.Point(705, 0);
            this.passwordshowbtn2.Margin = new System.Windows.Forms.Padding(4);
            this.passwordshowbtn2.Name = "passwordshowbtn2";
            this.passwordshowbtn2.Size = new System.Drawing.Size(33, 34);
            this.passwordshowbtn2.TabIndex = 5;
            this.passwordshowbtn2.Text = "*";
            this.passwordshowbtn2.UseVisualStyleBackColor = true;
            this.passwordshowbtn2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.passwordshowbtn2_MouseDown);
            this.passwordshowbtn2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.passwordshowbtn2_MouseUp);
            // 
            // confirmpasswordbox
            // 
            this.confirmpasswordbox.BackColor = System.Drawing.Color.White;
            this.confirmpasswordbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.confirmpasswordbox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmpasswordbox.ForeColor = System.Drawing.Color.Teal;
            this.confirmpasswordbox.Location = new System.Drawing.Point(244, 4);
            this.confirmpasswordbox.Margin = new System.Windows.Forms.Padding(4);
            this.confirmpasswordbox.MaxLength = 30;
            this.confirmpasswordbox.Name = "confirmpasswordbox";
            this.confirmpasswordbox.Size = new System.Drawing.Size(453, 29);
            this.confirmpasswordbox.TabIndex = 0;
            this.confirmpasswordbox.UseSystemPasswordChar = true;
            // 
            // confirmpassword
            // 
            this.confirmpassword.AutoSize = true;
            this.confirmpassword.BackColor = System.Drawing.Color.Transparent;
            this.confirmpassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.confirmpassword.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.confirmpassword.ForeColor = System.Drawing.Color.Teal;
            this.confirmpassword.Location = new System.Drawing.Point(4, 5);
            this.confirmpassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.confirmpassword.Name = "confirmpassword";
            this.confirmpassword.Size = new System.Drawing.Size(227, 28);
            this.confirmpassword.TabIndex = 0;
            this.confirmpassword.Text = "confirm password:";
            // 
            // createpasswordarea
            // 
            this.createpasswordarea.BackColor = System.Drawing.Color.White;
            this.createpasswordarea.Controls.Add(this.passwordshowbtn1);
            this.createpasswordarea.Controls.Add(this.createpasswordbox);
            this.createpasswordarea.Controls.Add(this.createpassword);
            this.createpasswordarea.Location = new System.Drawing.Point(15, 299);
            this.createpasswordarea.Margin = new System.Windows.Forms.Padding(4);
            this.createpasswordarea.Name = "createpasswordarea";
            this.createpasswordarea.Size = new System.Drawing.Size(743, 37);
            this.createpasswordarea.TabIndex = 1;
            // 
            // passwordshowbtn1
            // 
            this.passwordshowbtn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.passwordshowbtn1.FlatAppearance.BorderSize = 0;
            this.passwordshowbtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.passwordshowbtn1.Font = new System.Drawing.Font("Verdana", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.passwordshowbtn1.ForeColor = System.Drawing.Color.Teal;
            this.passwordshowbtn1.Location = new System.Drawing.Point(705, 0);
            this.passwordshowbtn1.Margin = new System.Windows.Forms.Padding(4);
            this.passwordshowbtn1.Name = "passwordshowbtn1";
            this.passwordshowbtn1.Size = new System.Drawing.Size(33, 34);
            this.passwordshowbtn1.TabIndex = 5;
            this.passwordshowbtn1.Text = "*";
            this.passwordshowbtn1.UseVisualStyleBackColor = true;
            this.passwordshowbtn1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.passwordshowbtn1_MouseDown);
            this.passwordshowbtn1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.passwordshowbtn1_MouseUp);
            // 
            // createpasswordbox
            // 
            this.createpasswordbox.BackColor = System.Drawing.Color.White;
            this.createpasswordbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.createpasswordbox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createpasswordbox.ForeColor = System.Drawing.Color.Teal;
            this.createpasswordbox.Location = new System.Drawing.Point(244, 4);
            this.createpasswordbox.Margin = new System.Windows.Forms.Padding(4);
            this.createpasswordbox.MaxLength = 30;
            this.createpasswordbox.Name = "createpasswordbox";
            this.createpasswordbox.Size = new System.Drawing.Size(453, 29);
            this.createpasswordbox.TabIndex = 0;
            this.createpasswordbox.UseSystemPasswordChar = true;
            // 
            // createpassword
            // 
            this.createpassword.AutoSize = true;
            this.createpassword.BackColor = System.Drawing.Color.Transparent;
            this.createpassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.createpassword.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createpassword.ForeColor = System.Drawing.Color.Teal;
            this.createpassword.Location = new System.Drawing.Point(4, 5);
            this.createpassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.createpassword.Name = "createpassword";
            this.createpassword.Size = new System.Drawing.Size(214, 28);
            this.createpassword.TabIndex = 0;
            this.createpassword.Text = "create password:";
            // 
            // emailarea
            // 
            this.emailarea.BackColor = System.Drawing.Color.White;
            this.emailarea.Controls.Add(this.emailbox);
            this.emailarea.Controls.Add(this.email);
            this.emailarea.Location = new System.Drawing.Point(15, 160);
            this.emailarea.Margin = new System.Windows.Forms.Padding(4);
            this.emailarea.Name = "emailarea";
            this.emailarea.Size = new System.Drawing.Size(609, 37);
            this.emailarea.TabIndex = 1;
            // 
            // emailbox
            // 
            this.emailbox.BackColor = System.Drawing.Color.White;
            this.emailbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.emailbox.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.emailbox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.emailbox.ForeColor = System.Drawing.Color.Teal;
            this.emailbox.Location = new System.Drawing.Point(100, 4);
            this.emailbox.Margin = new System.Windows.Forms.Padding(4);
            this.emailbox.MaxLength = 30;
            this.emailbox.Name = "emailbox";
            this.emailbox.Size = new System.Drawing.Size(476, 29);
            this.emailbox.TabIndex = 0;
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.BackColor = System.Drawing.Color.Transparent;
            this.email.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.email.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Teal;
            this.email.Location = new System.Drawing.Point(4, 5);
            this.email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(86, 28);
            this.email.TabIndex = 0;
            this.email.Text = "email:";
            // 
            // namearea
            // 
            this.namearea.BackColor = System.Drawing.Color.White;
            this.namearea.Controls.Add(this.namebox);
            this.namearea.Controls.Add(this.name);
            this.namearea.Location = new System.Drawing.Point(15, 98);
            this.namearea.Margin = new System.Windows.Forms.Padding(4);
            this.namearea.Name = "namearea";
            this.namearea.Size = new System.Drawing.Size(609, 37);
            this.namearea.TabIndex = 1;
            // 
            // namebox
            // 
            this.namebox.BackColor = System.Drawing.Color.White;
            this.namebox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.namebox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.namebox.ForeColor = System.Drawing.Color.Teal;
            this.namebox.Location = new System.Drawing.Point(107, 4);
            this.namebox.Margin = new System.Windows.Forms.Padding(4);
            this.namebox.MaxLength = 30;
            this.namebox.Name = "namebox";
            this.namebox.Size = new System.Drawing.Size(469, 29);
            this.namebox.TabIndex = 0;
            // 
            // name
            // 
            this.name.AutoSize = true;
            this.name.BackColor = System.Drawing.Color.Transparent;
            this.name.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.name.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.name.ForeColor = System.Drawing.Color.Teal;
            this.name.Location = new System.Drawing.Point(4, 5);
            this.name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.name.Name = "name";
            this.name.Size = new System.Drawing.Size(90, 28);
            this.name.TabIndex = 0;
            this.name.Text = "name:";
            // 
            // createusernamearea
            // 
            this.createusernamearea.BackColor = System.Drawing.Color.White;
            this.createusernamearea.Controls.Add(this.creatusernamebox);
            this.createusernamearea.Controls.Add(this.createusername);
            this.createusernamearea.Location = new System.Drawing.Point(15, 231);
            this.createusernamearea.Margin = new System.Windows.Forms.Padding(4);
            this.createusernamearea.Name = "createusernamearea";
            this.createusernamearea.Size = new System.Drawing.Size(743, 37);
            this.createusernamearea.TabIndex = 1;
            // 
            // creatusernamebox
            // 
            this.creatusernamebox.BackColor = System.Drawing.Color.White;
            this.creatusernamebox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.creatusernamebox.CharacterCasing = System.Windows.Forms.CharacterCasing.Lower;
            this.creatusernamebox.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.creatusernamebox.ForeColor = System.Drawing.Color.Teal;
            this.creatusernamebox.Location = new System.Drawing.Point(244, 4);
            this.creatusernamebox.Margin = new System.Windows.Forms.Padding(4);
            this.creatusernamebox.MaxLength = 30;
            this.creatusernamebox.Name = "creatusernamebox";
            this.creatusernamebox.Size = new System.Drawing.Size(440, 29);
            this.creatusernamebox.TabIndex = 0;
            // 
            // createusername
            // 
            this.createusername.AutoSize = true;
            this.createusername.BackColor = System.Drawing.Color.Transparent;
            this.createusername.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.createusername.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createusername.ForeColor = System.Drawing.Color.Teal;
            this.createusername.Location = new System.Drawing.Point(4, 5);
            this.createusername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.createusername.Name = "createusername";
            this.createusername.Size = new System.Drawing.Size(224, 28);
            this.createusername.TabIndex = 0;
            this.createusername.Text = "create username:";
            // 
            // signupform
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1173, 615);
            this.Controls.Add(this.srightpanel);
            this.Controls.Add(this.sleftpanel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "signupform";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "signupform";
            this.sleftpanel.ResumeLayout(false);
            this.sleftpanel.PerformLayout();
            this.srightpanel.ResumeLayout(false);
            this.srightpanel.PerformLayout();
            this.confirmpasswordarea.ResumeLayout(false);
            this.confirmpasswordarea.PerformLayout();
            this.createpasswordarea.ResumeLayout(false);
            this.createpasswordarea.PerformLayout();
            this.emailarea.ResumeLayout(false);
            this.emailarea.PerformLayout();
            this.namearea.ResumeLayout(false);
            this.namearea.PerformLayout();
            this.createusernamearea.ResumeLayout(false);
            this.createusernamearea.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel sleftpanel;
        private System.Windows.Forms.Label sdevelopername;
        private System.Windows.Forms.Label sdevelopedby;
        private System.Windows.Forms.Label screatenewacc1;
        private System.Windows.Forms.Label slogintoyouraccount1;
        private System.Windows.Forms.Label sEasyDine;
        private System.Windows.Forms.Panel srightpanel;
        private System.Windows.Forms.Button ssignupbtn;
        private System.Windows.Forms.Button sloginbtn;
        private System.Windows.Forms.LinkLabel sclydenmail;
        private System.Windows.Forms.Label screatenewacc2;
        private System.Windows.Forms.LinkLabel saafilmail;
        private System.Windows.Forms.Button sclosebtn;
        private System.Windows.Forms.Label ssupport3;
        private System.Windows.Forms.Label ssupport2;
        private System.Windows.Forms.Label ssupport1;
        private System.Windows.Forms.Panel createpasswordarea;
        private System.Windows.Forms.Button passwordshowbtn1;
        private System.Windows.Forms.TextBox createpasswordbox;
        private System.Windows.Forms.Label createpassword;
        private System.Windows.Forms.Panel createusernamearea;
        private System.Windows.Forms.TextBox creatusernamebox;
        private System.Windows.Forms.Label createusername;
        private System.Windows.Forms.Panel confirmpasswordarea;
        private System.Windows.Forms.Button passwordshowbtn2;
        private System.Windows.Forms.TextBox confirmpasswordbox;
        private System.Windows.Forms.Label confirmpassword;
        private System.Windows.Forms.Panel emailarea;
        private System.Windows.Forms.TextBox emailbox;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Panel namearea;
        private System.Windows.Forms.TextBox namebox;
        private System.Windows.Forms.Label name;
    }
}